import json,shutil,subprocess,time,platform,os
from pathlib import Path
from collections import Counter
ROOT=Path('/tmp/issue55-variable-material-20260917');OUT=Path('intransitive/benchmarks/variable-material')
measure=json.loads((ROOT/'measurements.json').read_text());ph=measure['phases'][0]
ids=set(ph['observed_pids']);present=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,ni=,stat=,args='],text=True).splitlines():
 parts=line.split(None,4)
 if len(parts)==5 and int(parts[0]) in ids:present.append(dict(pid=int(parts[0]),ppid=int(parts[1]),nice=int(parts[2]),state=parts[3],command=parts[4]))
cleanup=dict(observed_experiment_pids_still_present=present,elapsed_from_original_launch=time.time()-(ROOT/'supervisor.log').stat().st_birthtime,platform=platform.platform(),logical_cpus=os.cpu_count(),note='Read-only check after supervisor completion; no signals sent to unrelated processes.')
(ROOT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n');assert not present
comparison=json.loads((ROOT/'comparison.json').read_text());audits=json.loads((ROOT/'verification.json').read_text());consensus=json.loads((ROOT/'consensus.json').read_text());counters=Counter();score_status=Counter()
for r in consensus['runs']:
 assert r['completed'];counters.update(r['outcomes']);score_status.update(s['status'] for m in r['matches'] for s in m['scores'])
rows=sorted((r for r in comparison['settings'] if not r['setting'].startswith('smoke')),key=lambda r:(not r['setting'].startswith('minimax'),r['setting']))
text='''**This test does not establish an improvement over the original flat-material
heuristic.** Official results favour flat material at depths one and two, while
the deeper/Monte Carlo results need to be read with unresolved games and the
small sample in mind. The new mode remains selectable; flat material stays the
default. Results below are from **variable material's** perspective.

| Setting | Official wins / losses / unfinished | After consensus wins / losses / inconclusive | Main wall (s) |
| --- | --- | --- | ---: |
'''
for r in rows:
 o=r['official'];c=r['consensus'];text+=f"| {r['setting']} | {o['wins']} / {o['losses']} / {o['unfinished']} | {c.get('wins',0)} / {c.get('losses',0)} / {c.get('inconclusive',0)} | {r['wall_seconds']:.2f} |\n"
text+='\nOfficial paired 95% intervals (including uncertainty from unresolved games):\n\n'
for r in rows:text+=f"- {r['setting']}: {r['official']['paired_interval_95']}\n"
text+='\nNo method/depth totals are pooled into a single win rate. Per-opening and\nper-colour outcomes, actual completed depths/simulations and work are available\nin [comparison.json](comparison.json).\n'
p=OUT/'README.md';s=p.read_text().replace('<!-- RESULTS -->',text)
minu,sec=divmod(measure['elapsed_seconds'],60)
outcomes=Counter()
for a in audits:outcomes.update(a['outcomes'])
resources=f'''## Measurements and audit

The full supervised corpus generation, smoke, 80-game comparison, replay audit
and consensus pass took **{int(minu)}m{sec:05.2f}s** ({measure['elapsed_seconds']:.2f} seconds).
The supervisor used nice 19 and OPENBLAS/OMP/MKL thread counts of one. Sampled
peak descendant RSS was **{ph['peak_sampled_tree_rss_bytes']/1048576:.1f} MiB**, at most
{ph['peak_processes']} processes, sampled every three seconds. Observed priorities:
`{ph['observed_priorities']}`; priority anomalies: **{len(ph['priority_anomalies'])}**.
These are shared-host measurements, not isolated throughput estimates.
All observed experiment descendants were absent at cleanup.

All **{sum(a['records'] for a in audits)} records / {sum(a['moves'] for a in audits)} moves** passed replay and exact report
reconstruction. Played moves completed their requested search. Recorded outcome
counts, including the four smoke games, were `{dict(outcomes)}`. The separate
consensus analysis classified them as `{dict(counters)}`. Evaluator completion
statuses: `{dict(score_status)}`. These accounting totals include repeated starts
and smoke games and are not an aggregate strength result.

[Initial-board evaluations](initial-evaluations.json) record raw module terms and
MCTS value calibration for the frozen positions. They were computed after the
games, without selecting positions or changing settings in response.
'''
s=s.replace('<!-- MEASUREMENTS -->',resources)
s=s.replace('<!-- EVIDENCE -->','''- [Frozen design and candidates](design.json)
- [Results by setting, side and opening](comparison.json)
- [Consensus scores and alternative rankings](consensus.json)
- [Replay/report audit](verification.json)
- [Resource measurements](measurements.json), [cleanup](cleanup.json)
- [Full archive](runs.tar.gz), [SHA-256](runs.sha256): manifests, journals,
  complete reports, corpus histories, scripts, tests and monitor logs
''');p.write_text(s)
for name in ('design.json','comparison.json','consensus.json','verification.json','measurements.json','cleanup.json','initial-evaluations.json'):shutil.copy2(ROOT/name,OUT/name)
print(json.dumps(dict(elapsed=measure['elapsed_seconds'],records=sum(a['records'] for a in audits),moves=sum(a['moves'] for a in audits),consensus=dict(counters),cleanup=present)))
