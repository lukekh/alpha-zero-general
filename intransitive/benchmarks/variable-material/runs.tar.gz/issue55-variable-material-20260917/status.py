import json
from pathlib import Path
from collections import Counter
ROOT=Path('/tmp/issue55-variable-material-20260917')
if (ROOT/'progress.json').exists():
 p=json.loads((ROOT/'progress.json').read_text());print(json.dumps({k:p[k] for k in ('elapsed_seconds','peak_tree_rss_bytes','observed_priorities','priority_anomalies')}))
for folder in sorted(ROOT.iterdir()):
 if not (folder/'manifest.json').exists():continue
 spec=json.loads((folder/'manifest.json').read_text());who=next(c['sha256'] for c in spec['candidates'] if c['name']=='variable');counts=Counter();depths=Counter()
 for path in (folder/'matches').glob('*.json'):
  row=json.loads(path.read_text());colour=row['colours'].index(who)
  counts['wins' if row['status']=='win' and row['winner']==colour else 'losses' if row['status']=='win' else row['status']]+=1
 print(json.dumps(dict(setting=folder.name,complete=(folder/'report.json').exists(),attempted=sum(counts.values()),scheduled=len(spec['tasks']),outcomes=dict(counts))))
