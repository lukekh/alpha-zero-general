import json,math,time
from pathlib import Path
from intransitive.IntransitiveGame import IntransitiveGame
from intransitive.heuristics.config import SearchConfig
from intransitive.heuristics.budget import Budget
from intransitive.heuristics.evaluation import Evaluator
from intransitive.tournament.spec import unpack
from intransitive.tournament.runner import atomic_json
ROOT=Path('/tmp/issue55-variable-material-20260917');d=json.loads((ROOT/'design.json').read_text());positions=json.loads((ROOT/'positions.json').read_text());output=[]
for item in d['candidates']:
 config=SearchConfig(**item['evaluation']);rows=[]
 for p in positions:
  result=Evaluator(IntransitiveGame(modelling_draws=False),config).explain(unpack(p['state']),0,Budget(5_000_000,5),proof={'status':'unknown'},diagnostics=False)
  rows.append(dict(seed=p['seed'],state=p['sha256'],score=result['score'],raw_score=result.get('raw_score'),clipped=result.get('clipped',False),terms=result['terms'],piece_values=result.get('piece_values'),mcts_leaf_value=math.tanh(result['score']/400)))
 output.append(dict(candidate=item['name'],rows=rows,clipped=sum(r['clipped'] for r in rows),near_saturated_mcts_value=sum(abs(r['mcts_leaf_value'])>=.99 for r in rows)))
atomic_json(ROOT/'initial-evaluations.json',dict(note='Post-run diagnostic of frozen initial positions; static scores with proof disabled. Never used to select positions or alter play. MCTS near-saturation means absolute tanh(score/400) >= .99.',candidates=output))
print(json.dumps([{k:v for k,v in r.items() if k!='rows'} for r in output]))
