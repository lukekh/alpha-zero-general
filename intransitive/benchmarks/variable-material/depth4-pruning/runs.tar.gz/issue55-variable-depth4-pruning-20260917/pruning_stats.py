import json
from pathlib import Path
from collections import Counter
ROOT=Path('/tmp/issue55-variable-depth4-pruning-20260917')
result={}
for name in ('smoke-depth4','pruning-on','pruning-off'):
 folder=ROOT/name
 if not (folder/'manifest.json').exists():continue
 spec=json.loads((folder/'manifest.json').read_text());names={c['sha256']:c['name'] for c in spec['candidates']};players={}
 for path in sorted((folder/'matches').glob('*.json')):
  row=json.loads(path.read_text())
  for index,move in enumerate(row['moves']):
   # Move records carry the side used by the engine.
   who=names[move['candidate']]
   data=players.setdefault(who,dict(moves=0,depths=Counter(),stop_reasons=Counter(),effective=Counter(),counters=Counter(),work=0,nodes=0,elapsed=0.))
   r=move['result'];data['moves']+=1;data['depths'][r['completed_depth']]+=1;data['stop_reasons'][r['stop_reason']]+=1;data['effective'][str(r['selective']['effective'])]+=1
   for k,v in r['selective'].items():
    if type(v) is int and k!='depth':data['counters'][k]+=v
   for k in ('work','nodes','elapsed'):data[k]+=r[k]
 result[name]=players
(ROOT/'pruning-stats.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
