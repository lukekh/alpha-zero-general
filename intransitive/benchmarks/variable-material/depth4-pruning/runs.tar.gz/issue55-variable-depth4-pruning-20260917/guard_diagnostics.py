import json,base64
from pathlib import Path
ROOT=Path('/tmp/issue55-variable-depth4-pruning-20260917');rows=[]
for p in json.loads((ROOT/'positions.json').read_text()):
 b=base64.b64decode(p['state']);pieces=[(i,b[i*84] if b[i*84]<128 else b[i*84]-256) for i in range(81) if b[i*84]]
 counts=[sum((v<0)==side for i,v in pieces) for side in (0,1)]
 # Metadata is state[:,:,82:84].ravel(); meta[2] is A1 defender.
 a1=b[166]
 distance=min(max(abs(i%9-(8 if (v<0)==a1 else 0)),abs(i//9-(8 if (v<0)==a1 else 0))) for i,v in pieces)
 rows.append(dict(seed=p['seed'],pieces=counts,nearest_runner_to_own_goal=distance,excluded_by_piece_count=min(counts)<4,excluded_by_goal_distance=distance<=3))
(ROOT/'initial-guard-diagnostics.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
