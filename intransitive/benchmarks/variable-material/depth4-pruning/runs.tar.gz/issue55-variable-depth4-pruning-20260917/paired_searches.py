"""Post-run diagnostic of matched non-mate, completed depth-four prefix searches."""
import json
from pathlib import Path
from collections import defaultdict
ROOT=Path('/tmp/issue55-variable-depth4-pruning-20260917')
indexed={}
for arm in ('pruning-on','pruning-off'):
 folder=ROOT/arm;spec=json.loads((folder/'manifest.json').read_text());names={c['sha256']:c['name'] for c in spec['candidates']};variable=next(c['sha256'] for c in spec['candidates'] if c['name']=='variable');rows={}
 for path in (folder/'matches').glob('*.json'):
  row=json.loads(path.read_text());rows[(row['task']['position'],row['colours'].index(variable))]=row
 indexed[arm]=(names,rows)
pairs=[]
for key,on in indexed['pruning-on'][1].items():
 off=indexed['pruning-off'][1].get(key)
 if off is None:continue
 for a,b in zip(on['moves'],off['moves']):
  if a['before']!=b['before'] or a['side']!=b['side']:break
  ra,rb=a['result'],b['result']
  if ra['completed_depth']==rb['completed_depth']==4 and max(abs(ra['score']),abs(rb['score']))<90000:
   pairs.append(dict(position=key[0],variable_colour=key[1],state=a['before'],candidate=indexed['pruning-on'][0][a['candidate']],same_action=ra['action']==rb['action'],same_score=ra['score']==rb['score'],on_work=ra['work'],off_work=rb['work'],on_seconds=ra['elapsed'],off_seconds=rb['elapsed'],nmp_cutoffs=ra['selective']['nmp_cutoffs'],futility_pruned=ra['selective']['futility_pruned']))
summary={}
for name in ('flat','variable'):
 p=[r for r in pairs if r['candidate']==name];on=sum(r['on_work'] for r in p);off=sum(r['off_work'] for r in p)
 summary[name]=dict(searches=len(p),same_actions=sum(r['same_action'] for r in p),same_scores=sum(r['same_score'] for r in p),on_work=on,off_work=off,on_over_off_work=on/off if off else None,nmp_cutoffs=sum(r['nmp_cutoffs'] for r in p),futility_pruned=sum(r['futility_pruned'] for r in p))
(ROOT/'paired-searches.json').write_text(json.dumps(dict(note='Conditional matched-prefix diagnostic; excludes mate-range/early-proof searches and is not independent strength or a wall-time speedup estimate.',summary=summary,searches=pairs),indent=2)+'\n');print(json.dumps(summary))
