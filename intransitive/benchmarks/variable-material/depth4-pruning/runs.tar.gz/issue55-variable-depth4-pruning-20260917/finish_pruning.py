import json,subprocess,time,shutil
from pathlib import Path
from collections import Counter
ROOT=Path('/tmp/issue55-variable-depth4-pruning-20260917')
OUT=Path('intransitive/benchmarks/variable-material/depth4-pruning');OUT.mkdir(exist_ok=True)
measure=json.loads((ROOT/'measurements.json').read_text());phases=list(measure['phases'])
if (ROOT/'opening-diagnostic/measurements.json').exists():
 phases+=json.loads((ROOT/'opening-diagnostic/measurements.json').read_text())['phases']
pids={pid for phase in phases for pid in phase['observed_pids']};present=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,ni=,stat=,args='],text=True).splitlines():
 b=line.split(None,4)
 if len(b)==5 and int(b[0]) in pids:present.append(dict(pid=int(b[0]),ppid=int(b[1]),nice=int(b[2]),state=b[3],command=b[4]))
assert not present
cleanup=dict(observed_experiment_pids_still_present=present,elapsed_from_original_launch=time.time()-(ROOT/'supervisor.log').stat().st_birthtime,phases=phases,note='Read-only check after supervisors ended; no unrelated processes changed.')
(ROOT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
comparison=json.loads((ROOT/'comparison.json').read_text());stats=json.loads((ROOT/'pruning-stats.json').read_text());audits=json.loads((ROOT/'verification.json').read_text());cons=json.loads((ROOT/'consensus.json').read_text())
assert all(r['completed'] for r in cons['runs'])
text='''# Depth 4 after merging master: experimental pruning

This study merges master `032c6bb` and runs implementation `51ed837` with the
same eight legal eight-piece endgames and adopted coefficients as the
[previous depth-four comparison](../depth4/README.md). Each arm plays all eight
openings with colours swapped (16 scheduled games). Variable versus flat
material is the only evaluator difference within each arm.

Both Null Move Pruning and Futility Pruning are requested in the primary arm,
with the explicit experimental evaluator option. The control disables all three
flags. **PVS is enabled in both arms** to supply non-PV narrow windows. The old
comparison did not enable PVS, so it is not an isolated pruning baseline.
Neither material mode nor pruning is adopted as a new application default.

## Outcomes

All results are from variable material's perspective. Unresolved means unfinished
for official scoring and inconclusive after the requested consensus rule.

| Arm | Scoring | Wins | Losses | Unresolved | Excluded failures | Unattempted |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('pruning-on','pruning-off'):
 r=next(r for r in comparison['settings'] if r['setting']==name);o=r['official'];c=r['consensus']
 text+=f"| {name} | Official | {o['wins']} | {o['losses']} | {o['unfinished']} | {o['failures']} | {o['pending']} |\n"
 text+=f"| {name} | Official + consensus | {c.get('wins',0)} | {c.get('losses',0)} | {c.get('inconclusive',0)} | {c.get('excluded',0)} | {o['pending']} |\n"
text+='''
Consensus awards an unfinished game only when both competing configurations give
the same strict nonzero sign to the final board, from the same player's
perspective. Disagreement and ties remain inconclusive. Incomplete searches are
excluded, never credited as wins. Official journals are retained unchanged.
These are eight reused opening clusters, not independent held-out validation.
Do not pool arms or earlier depths as independent strength samples.

## What pruning actually did

Seven starting boards already have fewer than four pieces on one side, which
excludes their entire continuations from either pruning method. The remaining
4-versus-4 opening can qualify until captures or other guards exclude a node.
Requested/effective settings and actual counters are recorded separately.

Played-search counters in the pruning-enabled arm:

| Material | Played moves | NMP attempts | Verified NMP cutoffs | Futility eligible | Futility pruned |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for name in ('variable','flat'):
 d=stats['pruning-on'].get(name,{});c=d.get('counters',{})
 text+=f"| {name} | {d.get('moves',0)} | {c.get('nmp_attempts',0)} | {c.get('nmp_cutoffs',0)} | {c.get('futility_eligible',0)} | {c.get('futility_pruned',0)} |\n"
text+='''
These totals include only played searches; failed-response diagnostics remain
in the full journals. The experimental futility allowance uses absolute module
scales and the greatest current occupied piece-type value on either side in
variable mode. This is a local heuristic allowance, not a bound on nonlinear
future gains. All board guards, null verification, proof isolation and cache
separation from master are retained. See the [selective-search contract](../../../heuristics/SELECTIVE_SEARCH.md).

Selective mate-range scores must now finish the requested depth; they are not
certificates permitting an early stop. Unpruned proved results may still finish
earlier. Thus elapsed time and node totals also reflect this label distinction,
and games can follow different trajectories. Aggregate work is not a paired
speedup estimate.

## Supplemental opening diagnostic

'''
if (ROOT/'opening-diagnostic/result.json').exists():
 diagnostic=json.loads((ROOT/'opening-diagnostic/result.json').read_text())
 text+=f"Diagnostic status: **{diagnostic['status']}**. "
 if diagnostic['status']=='complete':
  rows=diagnostic['rows'];text+='''Eight searches compare both material modes with pruning on/off on the
initial board and the first 12 legal plies from the first frozen endgame history.
Positions are fixed without selecting for search outcomes. Each has the same
30-second / 100-million-work move ceiling. They supply no game wins or strength
ranking; input restoration and legal PVs are checked.

| Position | Material | Pruning | Completed depth | NMP cutoffs | Futility pruned | Complete |
| --- | --- | --- | ---: | ---: | ---: | --- |
'''
  for row in rows:
   r=row['result'];c=r['selective'];settings=row['settings']
   text+=f"| {row['position']} | {'variable' if settings['variable_material_enabled'] else 'flat'} | {'on' if settings['nmp_enabled'] else 'off'} | {r['completed_depth']} | {c.get('nmp_cutoffs',0)} | {c.get('futility_pruned',0)} | {row['complete']} |\n"
 else:text+=diagnostic.get('reason','')+'\n'
text+='''
## Protocol and verification

Depth 4; 30 seconds / 100 million logical work units per move; proof depth/tokens
2/64; 192 plies / 180 active seconds per game. Each arm has a 1600-second wall
cap; the second also respects time reserved for audit. Pruning-on runs first,
then pruning-off on the shared machine. Two two-ply smoke games precede them.
The outer allocation is one hour, with a 3500-second supervisor deadline and
bounded cleanup. The opening diagnostic retains that original deadline.

'''
text+=f"The main supervisor took **{measure['elapsed_seconds']:.2f} seconds**. Final cleanup\ncompleted **{cleanup['elapsed_from_original_launch']:.2f} seconds** after the original launch.\n"
text+=f"Peak sampled process-tree RSS across phases was **{max(p['peak_sampled_tree_rss_bytes'] for p in phases)/1048576:.1f} MiB**.\n"
text+=f"Observed priorities: `{sorted({n for p in phases for n in p['observed_priorities']})}`; priority anomalies: **{sum(len(p['priority_anomalies']) for p in phases)}**.\n"
text+='BLAS/OMP/MKL thread limits were one. No observed experiment descendants remained at cleanup.\n\n'
text+=f"All **{sum(a['records'] for a in audits)} records / {sum(a['moves'] for a in audits)} played moves** passed legal replay and exact report reconstruction.\n"
text+='''Every played selective move completed depth four; smoke games are excluded from
strength results. Integration validation passed 86 distinct focused Python
checks, 12 Rust tests and Clippy with warnings denied. Two Python label checks
initially failed to import absent dependencies; after installing those into this
worktree's local environment, both passed. The archive retains the initial
failures and successful reruns. No live teacher process or binary was changed.

## Evidence

- [Design](design.json), [per-opening results](comparison.json)
- [Consensus score pairs](consensus.json), [replay audit](verification.json)
- [Pruning counters and work](pruning-stats.json), [initial guard diagnostics](initial-guard-diagnostics.json)
- [Measurements](measurements.json), [cleanup](cleanup.json)
- [Full archive](runs.tar.gz), [SHA-256](runs.sha256)

The archive contains all manifests, journals, reports, diagnostic searches,
supervisor logs, test receipts and reproduction scripts. Run `study.py` through
`supervise.py` at the recorded implementation, after changing the original
`/tmp/issue55-variable-depth4-pruning-20260917` output root. The optional
`supervise-opening.py` uses the same original deadline; it does not start a new
hour. Saved journals can be replayed without starting engines.
'''
(OUT/'README.md').write_text(text)
for name in ('design.json','comparison.json','consensus.json','verification.json','measurements.json','cleanup.json','pruning-stats.json','initial-guard-diagnostics.json'):shutil.copy2(ROOT/name,OUT/name)
if (ROOT/'opening-diagnostic/result.json').exists():shutil.copy2(ROOT/'opening-diagnostic/result.json',OUT/'opening-diagnostic.json')
print(json.dumps(dict(records=sum(a['records'] for a in audits),moves=sum(a['moves'] for a in audits),elapsed=cleanup['elapsed_from_original_launch'])))
