"""Supplementary search-only diagnostic; no strength outcomes or position selection by results."""
import json,time
from dataclasses import asdict,replace
from pathlib import Path
from intransitive.heuristics import AlphaBetaPlayer,SearchConfig
from intransitive.tournament.spec import position,unpack
from intransitive.tournament.runner import atomic_json
from intransitive.IntransitiveGame import IntransitiveGame
ROOT=Path('/tmp/issue55-variable-depth4-pruning-20260917');OUT=ROOT/'opening-diagnostic'

def main():
 deadline=(ROOT/'supervisor.log').stat().st_birthtime+3500
 if deadline-time.time()<360:
  atomic_json(OUT/'result.json',dict(status='omitted',reason='Less than 360 seconds left in original allocation'));return
 starts=json.loads((ROOT/'positions.json').read_text());first=starts[0]
 positions=[position([],seed=first['seed'],stage='official',pool='validation'),position(first['opening_actions'][:12],seed=first['seed'],stage='opening',pool='validation')]
 settings=[dict(variable_material_enabled=variable,nmp_enabled=enabled,futility_enabled=enabled,selective_evaluator_enabled=enabled) for variable in (False,True) for enabled in (False,True)]
 base=SearchConfig(max_depth=4,time_limit=30.,node_limit=100_000_000,proof_depth=2,proof_nodes=64,pvs_enabled=True)
 atomic_json(OUT/'design.json',dict(positions=positions,settings=settings,base=base.to_dict(),scope='Eight fixed-root searches on initial position and first 12 legal plies of first frozen endgame history. Pruning observability only; no games or strength rankings. Same original one-hour allocation.'))
 warm=AlphaBetaPlayer(config=replace(base,max_depth=1,node_limit=10000));warm._prepare();warm.analyze(unpack(positions[0]['state']))
 game=IntransitiveGame();rows=[]
 for index,p in enumerate(positions):
  for setting in settings:
   state=unpack(p['state']);before=state.tobytes();begin=time.perf_counter();cpu=time.process_time()
   result=AlphaBetaPlayer(config=replace(base,**setting)).analyze(state)
   assert state.tobytes()==before
   board=state.copy();side=len(p['opening_actions'])%2
   for action in result.pv:
    assert game.getValidMoves(board,side)[action]
    board,side=game.getNextState(board,side,action)
   complete=not result.stopped and result.selection_source=='completed_iteration' and (result.completed_depth==4 or result.stop_reason=='proven_result')
   rows.append(dict(position=index,sha256=p['sha256'],settings=setting,complete=complete,result=asdict(result),cpu_seconds=time.process_time()-cpu,wall_seconds=time.perf_counter()-begin,pv_legal=True,input_restored=True))
   atomic_json(OUT/'result.json',dict(status='running',rows=rows))
 atomic_json(OUT/'result.json',dict(status='complete',rows=rows))
if __name__=='__main__':main()
