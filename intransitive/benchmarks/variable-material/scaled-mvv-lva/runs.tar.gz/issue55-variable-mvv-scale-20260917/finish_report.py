import json,time,subprocess,shutil
from pathlib import Path
ROOT=Path('/tmp/issue55-variable-mvv-scale-20260917');OUT=Path('intransitive/benchmarks/variable-material/scaled-mvv-lva');OUT.mkdir(exist_ok=True)
measure=json.loads((ROOT/'measurements.json').read_text());phase=measure['phases'][0];pids=set(phase['observed_pids']);present=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,ni=,stat=,args='],text=True).splitlines():
 b=line.split(None,4)
 if len(b)==5 and int(b[0]) in pids:present.append(dict(pid=int(b[0]),ppid=int(b[1]),nice=int(b[2]),state=b[3],command=b[4]))
assert not present
cleanup=dict(observed_experiment_pids_still_present=present,elapsed_from_original_launch=time.time()-(ROOT/'supervisor.log').stat().st_birthtime,note='Read-only check after supervisor exit; no unrelated processes changed.')
(ROOT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
design=json.loads((ROOT/'design.json').read_text());comparison=json.loads((ROOT/'comparison.json').read_text());stats=json.loads((ROOT/'search-stats.json').read_text());audits=json.loads((ROOT/'verification.json').read_text());cons=json.loads((ROOT/'consensus.json').read_text());assert all(r['completed'] for r in cons['runs'])
text=f'''# Variable material at one twentieth scale, with and without MVV-LVA

Implementation `{design['revision']}` follows the [pruning comparison](../depth4-pruning/README.md).
Four settings cross variable material at full/one-twentieth scale with MVV-LVA
off/on. Each setting plays the same flat-material opponent on four openings,
with colours swapped: **eight scheduled games per setting**, 32 in total.
All use Minimax depth 4, PVS, both pruning methods and the explicit experimental
evaluator option. No evaluator or pruning defaults are adopted by this study.

## Results

**Neither scaling nor MVV-LVA showed a clear strength improvement.** On the
seven opening/colour pairs attempted by all four settings, consensus outcomes
were identical: **3 wins, 2 losses, 2 inconclusive**. The three pairs that
finished decisively in all settings also had identical winners (1 win, 2 losses).
Only full-scale/MVV-off reached the eighth game, whose interrupted prefix was
adjudicated a loss; its aggregate 3–3 versus 3–2 elsewhere is therefore not
evidence that scaling or ordering improved strength. See the explicit
[paired outcomes](paired-outcomes.json). The scaled configuration did change
play: for example, the loss on seed 2669 as colour 1 took 59 moves instead of 27.

All scores are from the variable-material candidate's perspective. Official
unfinished games and consensus-inconclusive games are different categories.

| Material scale | MVV-LVA | Official W–L–unfinished | Consensus W–L–inconclusive | Failures | Official pending |
| --- | --- | --- | --- | ---: | ---: |
'''
for name,scale,mvv in [('full-mvv-off',100,False),('full-mvv-on',100,True),('scaled-mvv-off',5,False),('scaled-mvv-on',5,True)]:
 r=next(r for r in comparison['settings'] if r['setting']==name);o=r['official'];c=r['consensus']
 rows=[json.loads(p.read_text()) for p in (ROOT/name/'matches').glob('*.json')]
 interrupted=sum(row['status']=='cancelled' for row in rows);missing=o['scheduled']-len(rows)
 text+=f"| {'Full' if scale==100 else '1/20'} | {'on' if mvv else 'off'} | {o['wins']}–{o['losses']}–{o['unfinished']} | {c.get('wins',0)}–{c.get('losses',0)}–{c.get('inconclusive',0)} | {o['failures']} | {o['pending']} ({interrupted} interrupted, {missing} unstarted) |\n"
text+='''
Official pending includes interrupted games, not just games never started. A
nonempty interrupted prefix can still receive a consensus result; do not add
that column to the consensus totals.

For an unfinished or interrupted game, both competing configurations must agree on a strict
nonzero sign for the final board to adjudicate a winner. Disagreement/ties remain
inconclusive. Incomplete-search failures are excluded and never become wins.
Official journals are not rewritten. Changing material scale also changes one
adjudicator, so consensus scores must be read alongside official outcomes.

These are **four reused opening clusters**, not held-out strength validation.
The positions are frozen subset indices 0,2,5,7 of the previous eight endgames:
seeds 1643,1652,2669,2639, two from each original corpus seed, including the sole
4-versus-4 opening where pruning can be eligible. This subset was selected before
MVV-LVA/scale results to fit the hour and retain that coverage. Do not pool arms
or previous experiments as independent samples. Per-opening outcomes and paired
uncertainty are retained in [comparison.json](comparison.json).

## What changed

Full variable material uses material coefficient **100**; one-twentieth uses
**5**. Flat opponents always use **100**. Since variable army totals are
normalized by a fixed 100, coefficient 5 is exactly equivalent to changing BASE
from 100 to 5. Changing BASE in both the numerator and normalization would cancel
the intended reduction. All other adopted coefficients are identical:
advantage 23.967050360966205, attack 25.714516982666414, defence 32.5643023919054,
with overload/pressure disabled.

In the saved five-versus-three-piece example, variable material drops from
+2009.68 to +100.48, while advantage stays +111.85, attack +45.53 and defence
−6.51. Total static evaluation drops from +2160.55 to +251.35. See
[module scales](../../../heuristics/MODULE_SCALE.md) and the
[selectable preset](../../../heuristics/configs/variable-material-scaled.json).
This changes the evaluator's balance, not merely a reporting unit.

MVV-LVA uses pre-move per-type values from each army's own counts. Within existing
tactical priority groups, it prefers the most valuable victim and then the
least valuable attacker. Wins, TT/PV preferences, previous root scores and
corner defence retain priority. No move is discarded. A positive uniform scale
leaves these relative capture keys unchanged. With flat material the keys tie,
so the original order is retained. The flag is shared by both players per arm;
its accounted work/time is included, including flat-mode ordering overhead.

Python reference and compiled ordering and Rust implement the option. It enters
search/cache identity, and statistics record actual ordering work. See the
[MVV-LVA contract](../../../heuristics/MVV_LVA.md). Full unpruned scores are
preserved by tests; selective search and finite caps can make ordering affect
moves and completion. This benchmark uses selective search throughout.

## Observed search activity

Played-search totals (failed-response details remain in the journals):

| Setting | Evaluator | Moves | MVV-LVA nodes | Capture candidates ranked | NMP cutoffs | Futility skips |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
'''
for arm in ('full-mvv-off','scaled-mvv-on','scaled-mvv-off','full-mvv-on'):
 for name in ('variable','flat'):
  d=stats.get(arm,{}).get(name,{});c=d.get('counters',{})
  text+=f"| {arm} | {name} | {d.get('moves',0)} | {c.get('mvv_lva_nodes',0)} | {c.get('mvv_lva_captures',0)} | {c.get('nmp_cutoffs',0)} | {c.get('futility_pruned',0)} |\n"
text+='''
## Limits and verification

Each move has **30 seconds / 100 million work units**, requested depth 4,
proof depth/tokens 2/64. Games have 192 plies / 180 active seconds. Selective
mate-range scores must also complete requested depth; they are not certificates
for early termination. All arms use the same settings except material coefficient
and MVV-LVA. Arm order is full/off, scaled/on, scaled/off, full/on; each has an
800-second wall cap, reduced if needed to reserve audit time before 3350 seconds.
Two two-ply smoke games precede the arms. The supervisor deadline is 3500 seconds
plus bounded cleanup, within the one-hour allocation.

'''
text+=f"Supervised elapsed time: **{measure['elapsed_seconds']:.2f} seconds**; cleanup completed\n**{cleanup['elapsed_from_original_launch']:.2f} seconds** after launch. Peak sampled process-tree\nRSS: **{phase['peak_sampled_tree_rss_bytes']/1048576:.1f} MiB**; priorities `{phase['observed_priorities']}`,\n**{len(phase['priority_anomalies'])} priority anomalies**, at most {phase['peak_processes']} processes.\n"
text+='BLAS/OMP/MKL limits were one. No observed experiment descendants remained.\n\n'
text+=f"All **{sum(a['records'] for a in audits)} records / {sum(a['moves'] for a in audits)} played moves** passed legal replay and\nexact report reconstruction. Smoke outcomes are not strength evidence.\n"
text+='''Before the run, 102 focused Python tests, 13 Rust tests and Clippy with warnings
denied passed. Tests cover lexicographic victim/attacker priorities, both army
perspectives, capture/pop restoration, reference/compiled/compact ordering,
complete legal move sets, exact unpruned scores, cancellation, native protocol
and cache isolation, and the exact one-twentieth material contribution with other
terms unchanged. Live teacher processes/binaries were not changed.

## Evidence

- [Frozen design](design.json), [results and uncertainty](comparison.json)
- [Consensus scores](consensus.json), [replay audit](verification.json)
- [Paired outcomes](paired-outcomes.json), [search counters and work](search-stats.json)
- [Measurements](measurements.json), [cleanup](cleanup.json)
- [Full archive](runs.tar.gz), [SHA-256](runs.sha256)

The archive includes all manifests, complete journals, reports, test receipts,
monitor logs and reproduction scripts. Run its `study.py` through `supervise.py`
at the recorded implementation after changing the original
`/tmp/issue55-variable-mvv-scale-20260917` output root, with a bounded resource
allocation. Earlier archives require their recorded implementation because
search/evaluator fingerprints have changed.
'''
(OUT/'README.md').write_text(text)
for name in ('design.json','comparison.json','consensus.json','verification.json','measurements.json','cleanup.json','search-stats.json','paired-outcomes.json'):shutil.copy2(ROOT/name,OUT/name)
print(json.dumps(dict(records=sum(a['records'] for a in audits),moves=sum(a['moves'] for a in audits),elapsed=cleanup['elapsed_from_original_launch'])))
