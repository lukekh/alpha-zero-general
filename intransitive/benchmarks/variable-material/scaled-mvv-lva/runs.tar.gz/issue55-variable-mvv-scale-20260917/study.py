import json,signal,threading,time,subprocess
from pathlib import Path
from collections import Counter
import numpy as np
from intransitive.IntransitiveGame import IntransitiveGame
from intransitive.IntransitiveConstants import action_destination
from intransitive.tournament.spec import candidate,manifest,protocol,generate_positions,position,replay_opening
from intransitive.tournament.runner import atomic_json,play_match,replay,validate_manifest
from intransitive.tournament.report import report
from intransitive.evolution.engines import EnginePool
from intransitive.benchmarks.evolution.adjudicate import analyze
ROOT=Path('/tmp/issue55-variable-mvv-scale-20260917');START=time.monotonic()

def corpus():
 starts=[];attempts=[];seen=set();game=IntransitiveGame(modelling_draws=False)
 for seed in (1601,2601):
  originals=generate_positions(seed=seed,lines=80,max_plies=240)
  atomic_json(ROOT/f'corpus-{seed}.json',originals)
  available=sorted((p for p in originals if p['pool']=='validation' and p['stage']=='endgame'),key=lambda p:p['sha256']);accepted=0
  for original in available:
   state=replay_opening(original['opening_actions']);side=len(original['opening_actions'])%2;actions=list(original['opening_actions']);rng=np.random.default_rng(original['seed']+200000)
   found=None
   for _ in range(160):
    if np.count_nonzero(state[:,:,0])<=8:
     item=position(actions,seed=original['seed'],stage='endgame',pool='validation')
     if item['orbit_sha256'] not in seen:found=item
     break
    legal=list(map(int,np.flatnonzero(game.getValidMoves(state,side))))
    if not legal:break
    captures=[a for a in legal if state[action_destination(a)[1],action_destination(a)[0],0]]
    a=int(rng.choice(captures if captures and rng.random()<.9 else legal));state,side=game.getNextState(state,side,a);actions.append(a)
    if game.getGameEnded(state,side).any():break
   attempts.append(dict(corpus_seed=seed,original_seed=original['seed'],original=original['sha256'],accepted=found is not None))
   if found is not None:
    starts.append(found);seen.add(found['orbit_sha256']);accepted+=1
   if accepted==4:break
  if accepted!=4:raise RuntimeError('Not enough distinct legal validation endgames')
 atomic_json(ROOT/'positions.json',starts);atomic_json(ROOT/'position-selection.json',attempts)
 return starts

def games(name,spec,cap):
 folder=ROOT/name;atomic_json(folder/'manifest.json',spec)
 limit=spec['protocols'][0]
 atomic_json(folder/'budget.json',dict(max_seconds=cap,max_games=len(spec['tasks']),max_reserved_work=len(spec['tasks'])*(20000+limit['max_plies']*limit['search']['node_limit'])))
 cancel=threading.Event();old={}
 for sig in (signal.SIGINT,signal.SIGTERM):old[sig]=signal.signal(sig,lambda *_:cancel.set())
 timer=threading.Timer(cap,cancel.set);timer.daemon=True;timer.start();pool=EnginePool(2);rows=[];begin=time.monotonic()
 try:
  for task in spec['tasks']:
   if cancel.is_set():break
   atomic_json(ROOT/'active.json',dict(setting=name,index=task['index'],scheduled=len(spec['tasks']),elapsed=time.monotonic()-START))
   row=play_match(spec,task,folder/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire);rows.append(row)
   print(json.dumps(dict(setting=name,index=task['index'],status=row['status'],winner=row['winner'])),flush=True)
 finally:
  timer.cancel();pool.close()
  for sig,handler in old.items():signal.signal(sig,handler)
 summary=report(spec,rows);summary['wall_seconds']=time.monotonic()-begin;atomic_json(folder/'report.json',summary)
 return rows

def audit(folders):
 audits=[];adjudications=[]
 for folder in folders:
  spec=json.loads((folder/'manifest.json').read_text());validate_manifest(spec)
  rows=sorted((json.loads(p.read_text()) for p in (folder/'matches').glob('*.json')),key=lambda r:r['task']['index'])
  for row in rows:
   assert row['task'] in spec['tasks'] and row['manifest_sha256']==spec['sha256']
   start=next(p for p in spec['positions'] if p['sha256']==row['task']['position']);replay(start,row)
   for move in row['moves']:
    result=move['result'];assert not result['stopped']
    if result['search_kind']=='mcts':assert result['completed_simulations']==result['requested_simulations']
    else:
     assert result['selection_source']=='completed_iteration'
     assert result['completed_depth']>=spec['protocols'][0]['search']['max_depth'] or result['stop_reason']=='proven_result'
     assert result['selective']['effective']==spec['protocols'][0]['search']['nmp_enabled']
     assert result['ordering']['mvv_lva_enabled']==spec['protocols'][0]['search']['mvv_lva_enabled']
  saved=json.loads((folder/'report.json').read_text());rebuilt=report(spec,rows);rebuilt['wall_seconds']=saved['wall_seconds'];assert rebuilt==saved
  audits.append(dict(setting=folder.name,records=len(rows),moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows))))
  adjudications.append(analyze(folder,deadline=START+3420))
 atomic_json(ROOT/'verification.json',audits)
 atomic_json(ROOT/'consensus.json',dict(runs=adjudications,policy='Both competing effective configurations must agree on the sign of static final-board evaluation; official outcomes and original reports retained. Inconclusive outcomes excluded from alternative decided-game fraction.'))
 print(json.dumps(dict(audited_records=sum(a['records'] for a in audits),audited_moves=sum(a['moves'] for a in audits))),flush=True)

def limits(*, mvv, smoke=False):
 p=protocol('depth',depth=4,seconds=30,node_limit=100_000_000,proof_depth=2,proof_nodes=64,max_plies=2 if smoke else 192,game_seconds=60 if smoke else 180)
 p['search'].update(pvs_enabled=True,nmp_enabled=True,futility_enabled=True,selective_evaluator_enabled=True,mvv_lva_enabled=mvv)
 return p

def main():
 source=json.loads((ROOT/'source-positions.json').read_text())
 # Two positions per source corpus; retain the sole 4-versus-4 start.
 starts=[source[i] for i in (0,2,5,7)]
 atomic_json(ROOT/'positions.json',starts)
 arms=[('full-mvv-off',100.,False),('scaled-mvv-on',5.,True),('scaled-mvv-off',5.,False),('full-mvv-on',100.,True)]
 specs={}
 for name,material,mvv in arms:
  players=[candidate('variable',weights={'count_weight':material},variable_material_enabled=True),candidate('flat')]
  specs[name]=manifest(players,starts,[limits(mvv=mvv)],pool='validation')
 atomic_json(ROOT/'design.json',dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),arms=arms,protocols={name:spec['protocols'][0] for name,spec in specs.items()},candidates={name:spec['candidates'] for name,spec in specs.items()},position_seeds=[p['seed'] for p in starts],position_hashes=[p['sha256'] for p in starts],source='Subset indices 0,2,5,7 of prior eight endgames: two per source corpus, retaining sole4v4 opening. Selected before MVV/scale results; reused diagnostic corpus, not held out.',budget=dict(total_seconds=3600,supervisor_seconds=3500,arm_seconds=800,arm_games=8,smoke_seconds=180,smoke_games=2),scope='Four settings isolate variable material coefficient100 versus5 (BASE/20 equivalent), crossed with MVV-LVA off/on. Every opponent uses same pruning/PVS settings, flat material coefficient100. Same four colour-swapped openings per arm; no defaults adopted.'))
 smoke=manifest(specs['scaled-mvv-on']['candidates'],starts[:1],[limits(mvv=True,smoke=True)],pool='validation')
 rows=games('smoke-depth4',smoke,180)
 if len(rows)!=2 or any(r['status'] not in ('win','unfinished','depth_incomplete') for r in rows):raise RuntimeError('Operational smoke failure')
 for name,material,mvv in arms:
  atomic_json(ROOT/f'inputs/{name}.json',specs[name])
  games(name,specs[name],min(800,max(1,3350-(time.monotonic()-START))))
 audit([ROOT/'smoke-depth4']+[ROOT/name for name,_,_ in arms])
 atomic_json(ROOT/'finished.json',dict(elapsed_seconds=time.monotonic()-START,status='complete'))
if __name__=='__main__':main()
