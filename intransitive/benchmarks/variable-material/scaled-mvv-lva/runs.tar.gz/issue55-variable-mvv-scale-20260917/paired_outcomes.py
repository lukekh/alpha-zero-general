"""Align all four settings by opening and variable candidate colour."""
import json
from pathlib import Path
from intransitive.tournament.spec import digest
ROOT=Path('/tmp/issue55-variable-mvv-scale-20260917')
cons=json.loads((ROOT/'consensus.json').read_text());runs={Path(r['folder']).name:r for r in cons['runs']};arms=('full-mvv-off','full-mvv-on','scaled-mvv-off','scaled-mvv-on');paired={}
for name in arms:
 folder=ROOT/name;spec=json.loads((folder/'manifest.json').read_text());variable=next(c['sha256'] for c in spec['candidates'] if c['name']=='variable');labels={r['match_key']:r for r in runs[name]['matches']};rows={json.loads(p.read_text())['task']['id']:json.loads(p.read_text()) for p in (folder/'matches').glob('*.json')}
 for task in spec['tasks']:
  side=task['colours'].index(variable);key=(task['position'],side);p=next(p for p in spec['positions'] if p['sha256']==key[0]);entry=paired.setdefault(key,dict(seed=p['seed'],position=key[0],variable_colour=side,arms={}))
  row=rows.get(task['id'])
  if row is None:entry['arms'][name]=dict(status='not_started',official='missing',consensus='missing');continue
  label=labels[digest(dict(manifest=spec['sha256'],task=task['id']))]
  entry['arms'][name]=dict(status=row['status'],official=('win' if row['winner']==side else 'loss') if row['status']=='win' else row['status'],consensus=('win' if label['effective_winner']==side else 'loss') if label['effective_winner'] is not None else label['outcome'],moves=len(row['moves']))
contrasts=[]
for first,second in (('full-mvv-off','scaled-mvv-off'),('full-mvv-on','scaled-mvv-on'),('full-mvv-off','full-mvv-on'),('scaled-mvv-off','scaled-mvv-on')):
 common=[(e['arms'][first],e['arms'][second]) for e in paired.values() if e['arms'][first]['official'] in ('win','loss') and e['arms'][second]['official'] in ('win','loss')]
 contrasts.append(dict(first=first,second=second,common_official_decisions=len(common),same=sum(a['official']==b['official'] for a,b in common),loss_to_win=sum(a['official']=='loss' and b['official']=='win' for a,b in common),win_to_loss=sum(a['official']=='win' and b['official']=='loss' for a,b in common)))
(ROOT/'paired-outcomes.json').write_text(json.dumps(dict(note='Post-run alignment, with missing and interrupted games explicit. Conditional common completed outcomes are not an independent validation set.',contrasts=contrasts,positions=list(paired.values())),indent=2)+'\n');print(json.dumps(contrasts))
