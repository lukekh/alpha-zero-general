import json,time,subprocess,shutil
from pathlib import Path
from collections import Counter
ROOT=Path('/tmp/issue55-variable-depth4-20260917');OUT=Path('intransitive/benchmarks/variable-material/depth4')
measure=json.loads((ROOT/'measurements.json').read_text());phase=measure['phases'][0];ids=set(phase['observed_pids']);present=[]
retry_measure=json.loads((ROOT/'retry/measurements.json').read_text())
for retry_phase in retry_measure['phases']:ids.update(retry_phase['observed_pids'])
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,ni=,stat=,args='],text=True).splitlines():
 b=line.split(None,4)
 if len(b)==5 and int(b[0]) in ids:present.append(dict(pid=int(b[0]),ppid=int(b[1]),nice=int(b[2]),state=b[3],command=b[4]))
assert not present
cleanup=dict(observed_experiment_pids_still_present=present,elapsed_from_original_launch=time.time()-(ROOT/'supervisor.log').stat().st_birthtime,retry_measurements=retry_measure,note='Read-only check after both supervisors completed; no unrelated processes changed.')
(ROOT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
comparison=json.loads((ROOT/'comparison.json').read_text());r=next(r for r in comparison['settings'] if r['setting']=='minimax-d4');o=r['official'];c=r['consensus']
audits=json.loads((ROOT/'verification.json').read_text());cons=json.loads((ROOT/'consensus.json').read_text());labels=Counter();evaluation_status=Counter();completed=Counter();reasons=Counter()
for run in cons['runs']:
 assert run['completed'];labels.update(run['outcomes']);evaluation_status.update(s['status'] for m in run['matches'] for s in m['scores'])
for p in (ROOT/'minimax-d4/matches').glob('*.json'):
 game=json.loads(p.read_text())
 for move in game['moves']:completed[move['result']['completed_depth']]+=1;reasons[move['result']['stop_reason']]+=1
(ROOT/'search-completion.json').write_text(json.dumps(dict(completed_depths=dict(completed),stop_reasons=dict(reasons)),indent=2)+'\n')
result=f'''Results from **variable material's** perspective:

| Scoring | Wins | Losses | Unresolved | Failures | Unattempted |
| --- | ---: | ---: | ---: | ---: | ---: |
| Official | {o['wins']} | {o['losses']} | {o['unfinished']} | {o['failures']} | {o['pending']} |
| Official + consensus | {c.get('wins',0)} | {c.get('losses',0)} | {c.get('inconclusive',0)} | {c.get('excluded',0)} | {o['pending']} |

Unresolved means unfinished in the official row and inconclusive after
adjudication in the second row. Consensus does not rewrite the official game
outcomes. The official paired 95% interval is **{o['paired_interval_95']}**;
these are only eight opening clusters. The results do not by themselves
establish a reliable general strength improvement.

[Per-opening and per-colour results](comparison.json) retain all outcomes.
Played-search completed-depth counts across both opponents were `{dict(completed)}`;
stop reasons were `{dict(reasons)}`. Earlier decisive proof can finish before
depth four; otherwise a played move must complete the requested depth.
'''
minutes,seconds=divmod(measure['elapsed_seconds'],60)
metrics=f'''## Measurements and verification

The supervised smoke, comparison, replay audit and consensus pass took
**{int(minutes)}m{seconds:05.2f}s** ({measure['elapsed_seconds']:.2f} seconds), within the one-hour cap.
Observed priorities were `{phase['observed_priorities']}`, with **{len(phase['priority_anomalies'])} priority anomalies**.
BLAS/OMP/MKL thread counts were one. Three-second sampling measured a peak
summed descendant RSS of **{phase['peak_sampled_tree_rss_bytes']/1048576:.1f} MiB**, at most
{phase['peak_processes']} processes. These are shared-machine measurements. No observed
experiment descendants remained at cleanup.

All **{sum(a['records'] for a in audits)} records / {sum(a['moves'] for a in audits)} played moves** passed replay and exact report
reconstruction. Accounting totals including smoke: consensus labels
`{dict(labels)}`; adjudicator statuses `{dict(evaluation_status)}`. Smoke results
are not counted as strength evidence.
'''
evidence='''- [Frozen design](design.json), [comparison](comparison.json)
- [Consensus score pairs](consensus.json), [replay audit](verification.json)
- [Search completion](search-completion.json)
- [Measurements](measurements.json), [cleanup](cleanup.json)
- [Full archive](runs.tar.gz), [SHA-256](runs.sha256)
'''
retry=json.loads((ROOT/'retry/comparison.json').read_text())
result+='\n## Paired retry with larger move limits\n\nThe opening whose primary game failed to complete depth four was retried in\nboth colours, with 60 seconds / 200 million work units per move. Game limits\nremain 192 plies / 180 active seconds, with a separate 560-second pair wall\ncap. The original one-hour supervisor deadline was retained. Primary records\nare not replaced or pooled with this diagnostic.\n\n'
for rr in retry['settings']:
 ro=rr['official'];rc=rr['consensus']
 result+=f"- {rr['setting']}: official {ro['wins']} wins, {ro['losses']} losses, {ro['unfinished']} unfinished, {ro['failures']} failures; after consensus {rc.get('wins',0)} wins, {rc.get('losses',0)} losses, {rc.get('inconclusive',0)} inconclusive, {rc.get('excluded',0)} excluded.\n"
result+=f"\nThe retry supervisor took {retry_measure['elapsed_seconds']:.2f} seconds. See [retry details](retry-comparison.json) and the full archive for score pairs and replay verification.\n"
shutil.copy2(ROOT/'retry/comparison.json',OUT/'retry-comparison.json')
shutil.copy2(ROOT/'retry/verification.json',OUT/'retry-verification.json')
p=OUT/'README.md';s=p.read_text().replace('<!-- RESULTS -->',result).replace('<!-- MEASUREMENTS -->',metrics).replace('<!-- EVIDENCE -->',evidence);p.write_text(s)
for name in ('design.json','comparison.json','consensus.json','verification.json','measurements.json','cleanup.json','search-completion.json'):shutil.copy2(ROOT/name,OUT/name)
print(json.dumps(dict(official={k:o[k] for k in ('wins','losses','unfinished','failures','pending')},consensus=c,elapsed=measure['elapsed_seconds'],records=sum(a['records'] for a in audits),moves=sum(a['moves'] for a in audits),completed_depths=dict(completed),stop_reasons=dict(reasons))))
