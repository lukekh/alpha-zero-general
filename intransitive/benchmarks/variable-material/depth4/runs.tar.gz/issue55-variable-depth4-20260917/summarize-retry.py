import json
from pathlib import Path
from collections import Counter
from intransitive.benchmarks.evolution.adjudicate import configuration_hash
ROOT=Path('/tmp/issue55-variable-depth4-20260917/retry')
cons=json.loads((ROOT/'consensus.json').read_text());by_folder={Path(r['folder']).name:r for r in cons['runs']};rows=[]
for folder in sorted(ROOT.iterdir()):
 if not (folder/'report.json').exists():continue
 spec=json.loads((folder/'manifest.json').read_text());r=json.loads((folder/'report.json').read_text());item=next(c for c in spec['candidates'] if c['name']=='variable');board=next(iter(r['leaderboards'].values()));official=next(c for c in board if c['name']=='variable');adjudicated=next(c for c in by_folder[folder.name]['ranking'] if c['config_hash']==configuration_hash(item))
 row=dict(setting=folder.name,official={k:official[k] for k in ('wins','losses','unfinished','failures','pending','scheduled','eligible','paired_interval_95','completed_depths','completed_simulations','observed_tree_depths','work','search_wall_seconds','by_colour')},consensus=adjudicated,wall_seconds=r['wall_seconds'],records=by_folder[folder.name]['records'],analysis_complete=by_folder[folder.name]['completed'],positions=[])
 matches={m['match_key']:m for m in by_folder[folder.name]['matches']}
 from intransitive.tournament.spec import digest
 for p in spec['positions']:
  scores=Counter();effective=Counter()
  for path in (folder/'matches').glob('*.json'):
   m=json.loads(path.read_text())
   if m['task']['position']!=p['sha256']:continue
   side=m['colours'].index(item['sha256']);scores['wins' if m['status']=='win' and m['winner']==side else 'losses' if m['status']=='win' else m['status']]+=1
   label=matches[digest(dict(manifest=spec['sha256'],task=m['task']['id']))];winner=label['effective_winner'];effective['wins' if winner==side else 'losses' if winner is not None else label['outcome']]+=1
  row['positions'].append(dict(seed=p['seed'],sha256=p['sha256'],official=dict(scores),consensus=dict(effective)))
 rows.append(row)
(ROOT/'comparison.json').write_text(json.dumps(dict(note='Variable-material candidate perspective. Identical adopted weights; methods and repeated positions not pooled as independent evidence.',settings=rows),indent=2)+'\n')
for row in rows:
 print(json.dumps(dict(setting=row['setting'],official={k:row['official'][k] for k in ('wins','losses','unfinished','failures','pending','paired_interval_95')},consensus=row['consensus'])))
