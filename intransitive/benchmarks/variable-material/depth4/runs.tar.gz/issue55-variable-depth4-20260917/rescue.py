"""Paired retry of openings with an incomplete depth-four search; separate caps."""
import json,time,subprocess
from pathlib import Path
import study as base
from intransitive.tournament.spec import manifest,protocol
from intransitive.tournament.runner import atomic_json
ROOT=Path('/tmp/issue55-variable-depth4-20260917');OUT=ROOT/'retry'

def main():
 original_launch=(ROOT/'supervisor.log').stat().st_birthtime
 base.ROOT=OUT;base.START=time.monotonic()-(time.time()-original_launch)
 spec=json.loads((ROOT/'minimax-d4/manifest.json').read_text());failed={}
 for path in (ROOT/'minimax-d4/matches').glob('*.json'):
  row=json.loads(path.read_text())
  if row['status']=='depth_incomplete':failed.setdefault(row['task']['position'],[]).append(row['task']['id'])
 limits=protocol('depth',depth=4,seconds=60,node_limit=200_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=180)
 atomic_json(OUT/'design.json',dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_manifest=spec['sha256'],failed_openings=failed,protocol=limits,rule='Retry every opening with a primary depth_incomplete result, both colours, ordered by state hash. No primary outcomes discarded or replaced. Separate 560-second cap per pair; original one-hour deadline retained. Omit later pairs if insufficient time remains.',original_launch_unix=original_launch,total_deadline_unix=original_launch+3500))
 folders=[];omitted=[]
 for index,key in enumerate(sorted(failed)):
  remaining=original_launch+3400-time.time()
  if remaining<580:omitted.append(key);continue
  start=next(p for p in spec['positions'] if p['sha256']==key)
  match=manifest(spec['candidates'],[start],[limits],pool='validation');name=f'pair-{index+1}'
  base.games(name,match,560);folders.append(OUT/name)
 base.audit(folders)
 atomic_json(OUT/'finished.json',dict(original_elapsed_seconds=time.time()-original_launch,omitted_openings=omitted,status='complete'))
if __name__=='__main__':main()
