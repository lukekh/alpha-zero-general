import time
START=time.monotonic()
import json, signal, threading
from pathlib import Path
from intransitive.evolution.engines import EnginePool
from intransitive.tournament.spec import candidate,manifest
from intransitive.tournament.runner import atomic_json,play_match
from intransitive.tournament.report import report

def main():
 root=Path('/tmp/issue55-hour-20260917');output=root/'final-screen'
 spec0=json.loads((root/'input.json').read_text());design=json.loads((root/'design.json').read_text())
 default=candidate('unchanged-default'); entries={}
 for folder in sorted((root/'benchmark').glob('*-8[12]')):
  for export in json.loads((folder/'candidates.json').read_text()):
   if not export['search']['eligible']:continue
   identity=export['manifest']['config_hash']
   entry=entries.setdefault(identity,dict(export=export,observations={},sources=[]))
   entry['sources'].append(dict(run=folder.name,generation=export['generation']))
   for key in export['validation_match_keys']:
    row=json.loads((folder/'matches'/key/'game.json').read_text())
    who=export['validation']['candidate']
    if who not in row['colours'] or default['sha256'] not in row['colours']:continue
    colour=row['colours'].index(who)
    entry['observations'].setdefault(key,[]).append(dict(win=row['status']=='win' and row['winner']==colour,loss=row['status']=='win' and row['winner']!=colour,status=row['status']))
 ranks=[]
 for identity,entry in entries.items():
  groups=list(entry['observations'].values());n=len(groups)
  if not n:continue
  wins=sum(all(r['win'] for r in g) for g in groups);losses=sum(all(r['loss'] for r in g) for g in groups)
  genes=entry['export']['genome']['genes'];active=sum(genes[g]>0 for g in ('attack','defence','overload','pressure'))
  ranks.append(dict(config_hash=identity,wins=wins,losses=losses,unresolved=n-wins-losses,unique_matches=n,lower=wins/n,completion=(wins+losses)/n,active_modules=active,sources=entry['sources']))
 ranks.sort(key=lambda r:(-r['lower'],-r['completion'],r['active_modules'],r['config_hash']))
 if not ranks:
  atomic_json(output/'selection.json',dict(ranking=[],status='no eligible training export',selection_rule=design['selection_rule']));return
 best=entries[ranks[0]['config_hash']]['export']
 selected=set(design['final_screen_positions']);starts=[p for p in spec0['positions'] if p['sha256'] in selected]
 spec=manifest([candidate('provisional',genome=best['genome']),default],starts,[spec0['limits']],pool='validation')
 atomic_json(output/'selection.json',dict(ranking=ranks,selection_rule=design['selection_rule'],source_export=best,scope=design['scope']))
 atomic_json(output/'manifest.json',spec);atomic_json(root/'provisional-genome.json',best['genome'])
 atomic_json(output/'budget.json',dict(max_seconds=750,max_games=40,max_reserved_work=40*(20_000+192*2_000_000),priority=19))
 cancel=threading.Event()
 for signum in (signal.SIGINT,signal.SIGTERM):signal.signal(signum,lambda *_:cancel.set())
 timer=threading.Timer(max(0.,750-(time.monotonic()-START)),cancel.set);timer.daemon=True;timer.start()
 pool=EnginePool(2);rows=[]
 try:
  for task in spec['tasks']:
   if cancel.is_set():break
   row=play_match(spec,task,output/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire);rows.append(row)
   print(json.dumps(dict(index=task['index'],status=row['status'],winner=row['winner'],plies=len(row['moves']),active_seconds=row['active_seconds'])),flush=True)
 finally:timer.cancel();pool.close()
 result=report(spec,rows);result['wall_seconds_including_imports']=time.monotonic()-START
 atomic_json(output/'report.json',result)
 print(json.dumps(dict(wall_seconds=result['wall_seconds_including_imports'],final_matches=result['final_matches'],boards=[{k:r[k] for k in ('name','wins','losses','unfinished','pending','eligible')} for r in result['leaderboards']['depth']])),flush=True)
if __name__=='__main__':main()
