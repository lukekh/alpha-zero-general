import json
from collections import Counter
from pathlib import Path
from intransitive.benchmarks.evolution.verify import verify
from intransitive.tournament.runner import validate_manifest,replay,atomic_json
from intransitive.tournament.spec import digest
root=Path('/tmp/issue55-hour-20260917');audits=[];records=[];keys=set();trajectories=set();configs=set();arms=[]
for folder in sorted((root/'benchmark').glob('*-8[12]')):
 audits.append(verify(folder));spec=json.loads((folder/'manifest.json').read_text());cp=json.loads((folder/'checkpoint.json').read_text());rep=json.loads((folder/'report.json').read_text());exports=json.loads((folder/'candidates.json').read_text())
 for key,entry in cp['ledger'].items():
  row=json.loads((folder/entry['record']).read_text());records.append(row);keys.add(key);trajectories.add(row['trajectory_sha256'])
 configs.update(cp['seen'])
 arms.append(dict(arm=folder.name,**{k:rep[k] for k in ('status','generations','unique_candidates','unique_matches','unique_trajectories','games_reserved','nodes_reserved','measured_search_work','known_child_cpu_seconds','wall_seconds','outcomes','failures','eligible_exports','child_peak_rss_bytes')},exports=exports))
atomic_json(root/'verification.json',audits)
extra=[];folder=root/'final-screen'
if (folder/'manifest.json').exists():
 spec=json.loads((folder/'manifest.json').read_text());validate_manifest(spec)
 rows=[json.loads(p.read_text()) for p in sorted((folder/'matches').glob('*.json'))]
 for row in rows:
  assert row['manifest_sha256']==spec['sha256'] and row['task'] in spec['tasks']
  pos=next(p for p in spec['positions'] if p['sha256']==row['task']['position'])
  replay(pos,row)
 extra.append(dict(run=str(folder),verified_matches=len(rows),verified_moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows))))
else:rows=[]
atomic_json(root/'additional-verification.json',extra)
summary=dict(design=json.loads((root/'design.json').read_text()),measurements=json.loads((root/'measurements.json').read_text()),arms=arms,comparison_totals=dict(records=len(records),distinct_match_keys=len(keys),distinct_trajectories=len(trajectories),distinct_configurations=len(configs),outcomes=dict(Counter(r['status'] for r in records)),win_reasons=dict(Counter(r.get('reason') for r in records if r['status']=='win'))),all_attempts=len(records)+len(rows),final_screen=json.loads((folder/'report.json').read_text()) if (folder/'report.json').exists() else None,final_selection=json.loads((folder/'selection.json').read_text()),depth_violations=sum(m['result']['completed_depth']<1 and m['result']['stop_reason']!='proven_result' for r in records+rows for m in r['moves']))
atomic_json(root/'summary.json',summary)
print(json.dumps(dict(optimizer_verified=sum(x['verified_matches'] for x in audits),screen_verified=len(rows),all_attempts=summary['all_attempts'],depth_violations=summary['depth_violations'])))
