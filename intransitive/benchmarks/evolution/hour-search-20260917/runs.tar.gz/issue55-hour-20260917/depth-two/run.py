import time
START=time.monotonic()
import json, signal, threading
from pathlib import Path
from intransitive.evolution.engines import EnginePool
from intransitive.tournament.spec import candidate,manifest,protocol
from intransitive.tournament.runner import atomic_json,play_match
from intransitive.tournament.report import report

def main():
 root=Path('/tmp/issue55-hour-20260917');output=root/'depth-two'
 original=json.loads((root/'input.json').read_text());design=json.loads((root/'design.json').read_text())
 genome=json.loads((root/'provisional-genome.json').read_text())
 used=set(original['validation'])|set(design['final_screen_positions'])
 starts=sorted((p for p in original['positions'] if p['pool']=='validation' and p['sha256'] not in used),key=lambda p:p['sha256'])
 assert len(starts)==16
 limits=protocol('depth',depth=2,seconds=4.,node_limit=5_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=20.)
 spec=manifest([candidate('provisional',genome=genome),candidate('unchanged-default')],starts,[limits],pool='validation')
 atomic_json(output/'manifest.json',spec)
 atomic_json(output/'design.json',dict(source_selection=str(root/'final-screen/selection.json'),genome=genome,selection='Same frozen genome after the positive depth-one development screen; all 16 remaining validation lines, sorted by stable position hash. No held-out games.',budget=dict(max_seconds=670,supervisor_deadline_seconds=700,max_games=32,max_reserved_work=32*(20_000+192*5_000_000),priority=19),protocol=limits,required_completed_depth=2,scope='Separate depth-two transfer screen; never pool with depth-one evidence. Unaccepted candidate for separate held-out acceptance.'))
 cancel=threading.Event()
 for signum in (signal.SIGINT,signal.SIGTERM):signal.signal(signum,lambda *_:cancel.set())
 timer=threading.Timer(max(0.,670-(time.monotonic()-START)),cancel.set);timer.daemon=True;timer.start()
 pool=EnginePool(2);rows=[]
 try:
  for task in spec['tasks']:
   if cancel.is_set():break
   row=play_match(spec,task,output/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire);rows.append(row)
   print(json.dumps(dict(index=task['index'],status=row['status'],winner=row['winner'],plies=len(row['moves']),active_seconds=row['active_seconds'])),flush=True)
 finally:timer.cancel();pool.close()
 result=report(spec,rows);result['wall_seconds_including_imports']=time.monotonic()-START
 for item in result['leaderboards']['depth']:
  item['depth_violations']=sum(m['result']['completed_depth']<2 and m['result']['stop_reason']!='proven_result' for r in rows for m in r['moves'] if m['candidate']==item['candidate'])
  item['eligible']=item['eligible'] and item['depth_violations']==0
 atomic_json(output/'report.json',result)
 print(json.dumps(dict(wall_seconds=result['wall_seconds_including_imports'],final_matches=result['final_matches'],boards=[{k:r[k] for k in ('name','wins','losses','unfinished','pending','eligible','depth_violations')} for r in result['leaderboards']['depth']])),flush=True)
if __name__=='__main__':main()
