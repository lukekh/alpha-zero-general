import json
from pathlib import Path
from collections import Counter
r=Path('/tmp/issue55-hour-20260917/depth-two');p=json.loads((r/'manifest.json').read_text());who=next(c['sha256'] for c in p['candidates'] if c['name']=='provisional');rows=[json.loads(f.read_text()) for f in (r/'matches').glob('*.json')]
w=sum(x['status']=='win' and x['colours'][x['winner']]==who for x in rows);l=sum(x['status']=='win' and x['colours'][x['winner']]!=who for x in rows)
print(json.dumps(dict(wins=w,losses=l,statuses=dict(Counter(x['status'] for x in rows)),depth_violations=sum(m['result']['completed_depth']<2 and m['result']['stop_reason']!='proven_result' for x in rows for m in x['moves']),elapsed=json.loads((r/'progress.json').read_text())['elapsed_seconds'])))
