import json
from collections import Counter
from pathlib import Path
from intransitive.tournament.runner import validate_manifest,replay,atomic_json
from intransitive.tournament.report import report
root=Path('/tmp/issue55-hour-20260917');folder=root/'depth-two'
spec=json.loads((folder/'manifest.json').read_text());validate_manifest(spec)
rows=[json.loads(p.read_text()) for p in sorted((folder/'matches').glob('*.json'))]
rows.sort(key=lambda r:r['task']['index'])
for row in rows:
 assert row['manifest_sha256']==spec['sha256'] and row['task'] in spec['tasks'] and row['colours']==row['task']['colours']
 pos=next(p for p in spec['positions'] if p['sha256']==row['task']['position']);replay(pos,row)
rebuilt=report(spec,rows)
for item in rebuilt['leaderboards']['depth']:
 item['depth_violations']=sum(m['result']['completed_depth']<2 and m['result']['stop_reason']!='proven_result' for r in rows for m in r['moves'] if m['candidate']==item['candidate'])
 item['eligible']=item['eligible'] and item['depth_violations']==0
saved=json.loads((folder/'report.json').read_text());rebuilt['wall_seconds_including_imports']=saved['wall_seconds_including_imports'];assert rebuilt==saved
source=json.loads((root/'summary.json').read_text());used=set(source['design']['final_screen_positions'])|set(json.loads((root/'input.json').read_text())['validation'])
assert not used.intersection(spec['selected_positions']);assert all(p['pool']=='validation' for p in spec['positions'])
audit=dict(verified_matches=len(rows),verified_moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows)),fresh_positions=len(spec['selected_positions']),depth_violations=sum(i['depth_violations'] for i in saved['leaderboards']['depth']))
atomic_json(folder/'verification.json',audit)
source['depth_two']=saved;source['depth_two_design']=json.loads((folder/'design.json').read_text());source['depth_two_measurements']=json.loads((folder/'measurements.json').read_text());source['all_attempts']=source['comparison_totals']['records']+len(list((root/'final-screen/matches').glob('*.json')))+len(rows);source['total_supervised_seconds']=source['measurements']['elapsed_seconds']+source['depth_two_measurements']['elapsed_seconds']
source['conclusion']='Promising fresh development-validation results on legal endgames at depths one and two; separate corpora and protocols, no pooling, no held-out acceptance or default adoption.'
atomic_json(root/'summary.json',source)
print(json.dumps(audit))
