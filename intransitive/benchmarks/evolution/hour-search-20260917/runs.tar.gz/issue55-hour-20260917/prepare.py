import json, subprocess
from collections import Counter
from pathlib import Path
from intransitive.evolution.runner import prepare, smoke_receipt
from intransitive.evolution.strategy import Settings
from intransitive.tournament.spec import generate_positions, protocol
from intransitive.tournament.runner import atomic_json
root=Path('/tmp/issue55-hour-20260917')
corpus=generate_positions(seed=257,lines=120,max_plies=240)
positions=[p for p in corpus if p['stage']=='endgame']
settings=Settings(seed=81,population=3,generations=3,mutation_rate=.7,toggle_rate=.3,search_positions=2,validation_positions=2,max_seconds=650.,max_games=180,max_nodes=75_000_000_000,resident_engines=4)
limits=protocol('depth',depth=1,seconds=2.,node_limit=2_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=15.)
spec=prepare(settings,positions,limits,revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
receipt=smoke_receipt('/tmp/issue55-benchmark-20260917/smoke-pooled',spec)
used=set(spec['validation'])
starts=sorted((p for p in positions if p['pool']=='validation' and p['sha256'] not in used),key=lambda p:p['sha256'])[:20]
assert len(starts)==20
atomic_json(root/'corpus-full.json',corpus)
atomic_json(root/'corpus-endgames.json',positions)
atomic_json(root/'input.json',spec)
atomic_json(root/'design.json',dict(settings=settings.to_dict(),protocol=limits,corpus=dict(seed=257,lines=120,max_plies=240,stage='endgame',pools=dict(Counter(p['pool'] for p in positions))),optimizer_seeds=[81,82],smoke=receipt,budget=dict(total_seconds=3600,supervisor_deadline_seconds=3500,comparison_arm_seconds=650,comparison_arms=4,final_screen_seconds=750),final_screen_positions=[p['sha256'] for p in starts],selection_rule='Require an eligible training export; deduplicate validation records by full match key; rank unique direct-default validation games by conservative win fraction, then completion, fewer active optional modules, stable config hash. Freeze one genome before the final screen. No candidate if none has eligible training.',scope='Exploratory endgames; fixed depth one; fresh development validation, no held-out games or automatic adoption.'))
print(json.dumps(dict(manifest=spec['sha256'],pools=dict(Counter(p['pool'] for p in positions)),final_positions=len(starts))),flush=True)
