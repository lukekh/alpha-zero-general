import json
from pathlib import Path
from collections import Counter
r=Path('/tmp/issue55-hour-20260917')
p=json.loads((r/'progress.json').read_text())
print(json.dumps({k:p[k] for k in ('phase','elapsed_seconds','phase_seconds','peak_tree_rss_bytes','observed_priorities')}))
for f in sorted((r/'benchmark').glob('*-8[12]')):
 p=json.loads((f/'checkpoint.json').read_text())
 print(json.dumps(dict(arm=f.name,generation=p['generation'],phase=p['phase'],attempts=p['games_reserved'],outcomes=dict(Counter(x['status'] for x in p['ledger'].values())),exports=[dict(generation=x['generation'],eligible=x['eligible'],training={k:x['search'][k] for k in ('wins','losses','unfinished','eligible')},validation={k:x['validation'][k] for k in ('wins','losses','unfinished','eligible')}) for x in p['exports'][-1:]]),sort_keys=True))
if (r/'final-screen'/'report.json').exists():
 p=json.loads((r/'final-screen'/'report.json').read_text())
 print(json.dumps(dict(final=[{k:x[k] for k in ('name','wins','losses','unfinished','eligible','pending','paired_interval_95')} for x in p['leaderboards']['depth']])))
