import json
from pathlib import Path
import subprocess
import sys
import time

prefix = Path(sys.argv[1])
command = sys.argv[2:]
start, peak, peak_processes = time.monotonic(), 0, 0
with prefix.with_suffix('.log').open('w') as log:
    process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    try:
        while process.poll() is None:
            output = subprocess.check_output(['ps', '-axo', 'pid=,ppid=,rss=,ni='], text=True)
            rows = [tuple(map(int, line.split())) for line in output.splitlines() if line.strip()]
            descendants = {process.pid}
            while True:
                expanded = descendants | {pid for pid, parent, _, _ in rows if parent in descendants}
                if expanded == descendants:
                    break
                descendants = expanded
            selected = [row for row in rows if row[0] in descendants]
            peak = max(peak, sum(row[2] * 1024 for row in selected))
            peak_processes = max(peak_processes, len(selected))
            if any(row[3] != 19 for row in selected):
                # nice(1) can briefly exist before changing its own priority.
                if time.monotonic() - start > 2:
                    raise RuntimeError('A benchmark process did not inherit nice=19')
            time.sleep(1)
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=30)
result = dict(command=command, exit_code=process.returncode, wall_seconds=time.monotonic()-start,
              sampled_tree_peak_rss_bytes=peak, peak_process_count=peak_processes,
              nice=19, sample_interval_seconds=1)
prefix.with_suffix('.measurement.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result))
sys.exit(process.returncode)
