import json,time,subprocess
from pathlib import Path
from collections import Counter
from intransitive.heuristics.tuning import Genome
from intransitive.tournament.spec import digest
R=Path('/tmp/issue55-variable-evolution-20260917')
read=lambda p:json.loads(p.read_text())
cons={str(Path(r['folder'])):r for r in read(R/'consensus.json')['runs']}
output=dict(selection=read(R/'selection.json'),screens=[],search_activity={},unique_genomes={},completion_rejected_candidates=[])
for folder in sorted((R/'runs').glob('*')):
 state=read(folder/'checkpoint.json');spec=read(folder/'manifest.json')
 for generation in state['history']:
  for entry in generation['search']['leaderboards']['depth']:
   if (entry['role']=='population' and not entry['eligible'] and entry['wins']>entry['losses']
       and not entry['failures'] and entry['unfinished']):
    output['completion_rejected_candidates'].append(dict(arm=folder.name,generation=generation['generation'],
      genome=state['seen'][entry['config_hash']],training=entry,
      note='Post-hoc inspection of training results only; not independently validated or selected for primary deeper checks.'))
 for g in list(state['seen'].values())+state['population']:
  genome=Genome.from_json(json.dumps(g));output['unique_genomes'][genome.config_hash]=g
for folder in [R/'smoke',*sorted((R/'runs').glob('*')),*sorted(R.glob('screen-depth*')),*sorted(R.glob('focused/*/screen-depth*'))]:
 if not folder.is_dir():continue
 paths=list((folder/'matches').glob('*/game.json')) if (folder/'checkpoint.json').exists() else list((folder/'matches').glob('*.json'))
 stats=dict(records=len(paths),played_moves=0,depths=Counter(),stop_reasons=Counter(),outcomes=Counter(),selective=Counter(),ordering=Counter(),work=0,failed_searches=[])
 for p in paths:
  row=read(p);spec=read(p.parent/'manifest.json' if p.name=='game.json' else folder/'manifest.json');requested=spec['protocols'][0]['search']['max_depth'];stats['outcomes'][row['status']]+=1
  if row.get('failed_response'):
   f=row['failed_response'];f=f.get('result',f);stats['failed_searches'].append(dict(status=row['status'],completed_depth=f.get('completed_depth'),stop_reason=f.get('stop_reason'),work=f.get('work'),elapsed=f.get('elapsed')))
  for move in row['moves']:
   result=move['result'];assert not result['stopped'];assert result['completed_depth']>=requested or result['stop_reason']=='proven_result'
   stats['played_moves']+=1;stats['depths'][result['completed_depth']]+=1;stats['stop_reasons'][result['stop_reason']]+=1;stats['work']+=result['work']
   for field in ('selective','ordering'):
    for k,v in result.get(field,{}).items():
     if type(v) is int:stats[field][k]+=v
 output['search_activity'][str(folder.relative_to(R))]=stats
 if not folder.name.startswith('screen-'):continue
 spec=read(folder/'manifest.json');selected=next(c for c in spec['candidates'] if c['name']=='selected');rows={r['task']['id']:r for r in map(read,paths)}
 labels={r['match_key']:r for r in cons[str(folder)]['matches']}
 for opponent in [c for c in spec['candidates'] if c!=selected]:
  counts=Counter();adjudicated=Counter();positions=[]
  for task in spec['tasks']:
   if opponent['sha256'] not in task['colours']:continue
   counts['scheduled']+=1;side=task['colours'].index(selected['sha256']);row=rows.get(task['id'])
   if row is None:counts['unstarted']+=1;continue
   status=row['status'];key=digest(dict(manifest=spec['sha256'],task=task['id']));label=labels[key]
   official=('wins' if row['winner']==side else 'losses') if status=='win' else status
   counts[official]+=1
   outcome=('wins' if label['effective_winner']==side else 'losses') if label['effective_winner'] is not None else label['outcome'];adjudicated[outcome]+=1
   positions.append(dict(position=task['position'],seed=task['seed'],selected_colour=side,official=official,consensus=outcome,moves=len(row['moves'])))
  output['screens'].append(dict(setting=str(folder.relative_to(R)),opponent=opponent['name'],official=dict(counts),consensus=dict(adjudicated),positions=positions))
(R/'summary.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(dict(screens=output['screens'],genome=output['selection'].get('genome'),records=sum(s['records'] for s in output['search_activity'].values()),moves=sum(s['played_moves'] for s in output['search_activity'].values()))))
