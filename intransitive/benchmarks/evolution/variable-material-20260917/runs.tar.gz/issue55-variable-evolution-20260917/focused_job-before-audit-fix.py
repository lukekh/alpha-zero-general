import json,time,sys,importlib.util
from pathlib import Path
from collections import Counter
from intransitive.tournament.runner import atomic_json,replay,validate_manifest
from intransitive.tournament.report import report
from intransitive.benchmarks.evolution.adjudicate import analyze
def main():
    R=Path('/tmp/issue55-variable-evolution-20260917');job=json.loads((R/'focus-design.json').read_text())['jobs'][sys.argv[1]]
    modspec=importlib.util.spec_from_file_location('original_study',R/'study.py');m=importlib.util.module_from_spec(modspec);modspec.loader.exec_module(m)
    m.ROOT=R/'focused'/sys.argv[1];m.START=time.monotonic();elapsed=time.time()-(R/'supervisor.log').stat().st_birthtime
    corpus=json.loads((R/'corpus-endgames.json').read_text());starts=[p for p in corpus if p['sha256'] in job['positions']]
    folder=m.screen(job['depth'],job['genome'],starts,min(job['seconds'],max(1,3400-elapsed)))
    read=lambda p:json.loads(p.read_text());spec=read(folder/'manifest.json');validate_manifest(spec);rows=[read(p) for p in (folder/'matches').glob('*.json')]
    for row in rows:replay(next(p for p in spec['positions'] if p['sha256']==row['task']['position']),row)
    saved=read(folder/'report.json');rebuilt=report(spec,rows);rebuilt['wall_seconds']=saved['wall_seconds'];assert saved==rebuilt
    atomic_json(m.ROOT/'verification.json',dict(run=str(folder),verified_matches=len(rows),verified_moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows))))
    atomic_json(m.ROOT/'consensus.json',analyze(folder,deadline=time.monotonic()+max(1,3460-(time.time()-(R/'supervisor.log').stat().st_birthtime))))
    atomic_json(m.ROOT/'complete.json',dict(elapsed_seconds=time.monotonic()-m.START))

if __name__=='__main__':main()
