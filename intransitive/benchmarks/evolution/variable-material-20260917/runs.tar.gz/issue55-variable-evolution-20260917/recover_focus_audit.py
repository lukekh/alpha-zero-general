"""Read-only replay and exact report reconstruction in original play order."""
import json,time
from pathlib import Path
from collections import Counter
from intransitive.tournament.runner import atomic_json,replay,validate_manifest
from intransitive.tournament.report import report
from intransitive.benchmarks.evolution.adjudicate import analyze
R=Path('/tmp/issue55-variable-evolution-20260917');read=lambda p:json.loads(p.read_text());checks=[];cons=[]
for folder in sorted(R.glob('focused/*/screen-depth*')):
 spec=read(folder/'manifest.json');validate_manifest(spec)
 rows=sorted((read(p) for p in (folder/'matches').glob('*.json')),key=lambda r:(r['task']['position'],r['task']['index']%2,r['task']['index']))
 assert all(row['status']!='running' for row in rows)
 for row in rows:replay(next(p for p in spec['positions'] if p['sha256']==row['task']['position']),row)
 saved=read(folder/'report.json');rebuilt=report(spec,rows);rebuilt['wall_seconds']=saved['wall_seconds'];assert saved==rebuilt
 check=dict(run=str(folder),verified_matches=len(rows),verified_moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows)));checks.append(check);atomic_json(folder.parent/'verification.json',check)
 result=analyze(folder,deadline=time.monotonic()+60);assert result['completed'];cons.append(result);atomic_json(folder.parent/'consensus.json',result)
old=read(R/'verification.json');old=[c for c in old if '/focused/' not in c['run']];atomic_json(R/'verification.json',old+checks)
old=read(R/'consensus.json');old['runs']=[c for c in old['runs'] if '/focused/' not in c['folder']]+cons;atomic_json(R/'consensus.json',old)
atomic_json(R/'focus-audit-recovery.json',dict(status='complete',reason='Report uses floating-point sums in input order. Filesystem order changed aggregate CPU seconds by ~2e-13 seconds. Exact reconstruction passes when replayed in the original declared interleaved play order. Original journals/reports and failed-worker exit codes preserved.',checks=checks,epoch=time.time()))
atomic_json(R/'focus-complete.json',dict(elapsed_original_seconds=time.time()-(R/'supervisor.log').stat().st_birthtime,audit_recovered=True))
print(json.dumps(checks))
