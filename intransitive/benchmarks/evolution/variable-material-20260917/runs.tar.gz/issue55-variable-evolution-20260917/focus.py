import json,time,subprocess,os,signal
from pathlib import Path
R=Path('/tmp/issue55-variable-evolution-20260917');born=(R/'supervisor.log').stat().st_birthtime
read=lambda p:json.loads(p.read_text())
def write(name,data):
 p=R/name;q=p.with_suffix('.tmp');q.write_text(json.dumps(data,indent=2)+'\n');q.replace(p)
state=read(R/'runs/evolution-171/checkpoint.json');rows=[r for r in state['history'][0]['search']['leaderboards']['depth'] if r['role']=='population' and not r['eligible'] and not r['failures'] and r['wins']>r['losses'] and r['completion_rate']<.8];rows.sort(key=lambda r:(-r['win_points_lower'],-r['completion_rate'],r['config_hash']));assert len(rows)>=2
original=read(R/'design.json');training=read(R/'runs/evolution-171/manifest.json');corpus=read(R/'corpus-endgames.json');used=set(training['validation'])|{h for starts in original['screen_positions'].values() for h in starts};used_seeds={p['seed'] for p in corpus if p['sha256'] in used};fresh=sorted((p for p in corpus if p['pool']=='validation' and p['seed'] not in used_seeds),key=lambda p:p['sha256'])[:4];assert len(fresh)==4
jobs={}
for label,row in zip(('raw-a','raw-b'),rows[:2]):jobs[label+'-depth2']=dict(depth=2,genome=state['seen'][row['config_hash']],training=row,positions=[p['sha256'] for p in fresh],seconds=650)
jobs['primary-depth4']=dict(depth=4,genome=read(R/'selected-genome.json'),positions=original['screen_positions']['4'],seconds=650)
jobs['raw-a-depth4']=dict(depth=4,genome=jobs['raw-a-depth2']['genome'],positions=original['screen_positions']['4'],seconds=650)
write('focus-design.json',dict(jobs=jobs,elapsed_at_launch=time.time()-born,resource_change='User explicitly requested graceful shutdown of competing training and benchmark processes, then focus compute on this task. Four independent validation jobs at normal priority0, one active search each, at most3 resident bots each; numerical-library threads1. Original one-hour deadline retained.',selection='Post-hoc diagnostic: seed171 generation0 more wins than losses, no failures, completion below.8; sort official wins/scheduled, completion, config hash; take first two. Primary selection and original evidence unchanged.',freshness='Depth2 uses four further development-validation lines excluded from all prior training/validation/screens. Depth4 repeats the two originally reserved positions; earlier attempt was interrupted by user. No heldout games.',budget='Each job capped650seconds or remaining time before3400s original elapsed; audit3460s, supervisor3500s plus bounded cleanup. Different compute allocation is a separate phase, not pooled with earlier time-capped games.'))
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=str(Path.cwd()))
processes={};logs=[];start=time.monotonic();seen=set();peak=0;priorities=set();anomalies=[];stop=None
for name in jobs:
 log=(R/(name+'.log')).open('w');logs.append(log);processes[name]=subprocess.Popen([str(Path('.venv/bin/python').absolute()),str(R/'focused_job.py'),name],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
while any(p.poll() is None for p in processes.values()):
 elapsed=time.time()-born
 if elapsed>=3500 and stop is None:
  stop=time.monotonic()
  for p in processes.values():
   if p.poll() is None:p.send_signal(signal.SIGTERM)
 if stop is not None and time.monotonic()-stop>20:
  for p in processes.values():
   if p.poll() is None:os.killpg(p.pid,signal.SIGKILL)
 rows=[]
 for line in subprocess.check_output(['ps','-axo','pid=,ppid=,rss=,ni=,stat=,comm='],text=True).splitlines():
  b=line.split(None,5)
  if len(b)==6:rows.append(dict(pid=int(b[0]),ppid=int(b[1]),rss=int(b[2])*1024,nice=int(b[3]),state=b[4],command=b[5]))
 ids={p.pid for p in processes.values()}
 while True:
  extra=ids|{r['pid'] for r in rows if r['ppid'] in ids}
  if extra==ids:break
  ids=extra
 tree=[r for r in rows if r['pid'] in ids];seen.update(ids);peak=max(peak,sum(r['rss'] for r in tree));priorities.update(r['nice'] for r in tree)
 write('focus-progress.json',dict(elapsed_original_seconds=elapsed,phase_seconds=time.monotonic()-start,peak_tree_rss_bytes=peak,priorities=sorted(priorities),jobs={n:p.poll() for n,p in processes.items()},live_processes=tree))
 time.sleep(3)
for log in logs:log.close()
write('focus-measurements.json',dict(elapsed_original_seconds=time.time()-born,phase_seconds=time.monotonic()-start,peak_tree_rss_bytes=peak,priorities=sorted(priorities),observed_pids=sorted(seen),exit_codes={n:p.returncode for n,p in processes.items()},deadline_signalled=stop is not None))
assert all(p.returncode==0 for p in processes.values())
checks=read(R/'verification.json');cons=read(R/'consensus.json')
for name in jobs:
 checks.append(read(R/'focused'/name/'verification.json'));cons['runs'].append(read(R/'focused'/name/'consensus.json'))
write('verification.json',checks);write('consensus.json',cons);write('focus-complete.json',dict(elapsed_original_seconds=time.time()-born))
