import time
START=time.monotonic()
import json,signal,threading,subprocess
from pathlib import Path
from dataclasses import replace
from collections import Counter
from intransitive.evolution.runner import prepare,run,smoke_receipt
from intransitive.evolution.strategy import Settings
from intransitive.evolution.engines import EnginePool
from intransitive.heuristics.tuning import Genome
from intransitive.tournament.spec import candidate,manifest,protocol,generate_positions
from intransitive.tournament.runner import atomic_json,play_match,replay,validate_manifest
from intransitive.tournament.report import report
from intransitive.benchmarks.evolution.verify import verify
from intransitive.benchmarks.evolution.adjudicate import analyze
ROOT=Path('/tmp/issue55-variable-evolution-20260917')
REVISION=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()

def limits(depth,smoke=False):
 p=protocol('depth',depth=depth,seconds=5 if smoke else (3 if depth==1 else 10 if depth==2 else 30),node_limit=50_000 if smoke else (3_000_000 if depth==1 else 30_000_000 if depth==2 else 100_000_000),proof_depth=0 if smoke else 2,proof_nodes=0 if smoke else 64,max_plies=2 if smoke else 192,game_seconds=15 if smoke else (12 if depth==1 else 30 if depth==2 else 90))
 p['search'].update(pvs_enabled=True,nmp_enabled=True,futility_enabled=True,selective_evaluator_enabled=True,mvv_lva_enabled=True)
 return p

def choose(folders):
 entries={}
 for folder in folders:
  for export in json.loads((folder/'candidates.json').read_text()):
   identity=export['manifest']['config_hash'];e=entries.setdefault(identity,dict(export=export,eligible=False,observations={},sources=[]))
   e['eligible'] |= export['eligible'];e['sources'].append(dict(arm=folder.name,generation=export['generation'],eligible=export['eligible']))
   who=export['validation']['candidate']
   for key in export['validation_match_keys']:
    row=json.loads((folder/'matches'/key/'game.json').read_text())
    if who not in row['colours']:continue
    side=row['colours'].index(who)
    e['observations'].setdefault(key,[]).append(dict(win=row['status']=='win' and row['winner']==side,loss=row['status']=='win' and row['winner']!=side))
 ranking=[]
 for identity,e in entries.items():
  groups=list(e['observations'].values());n=len(groups)
  if not n:continue
  w=sum(all(r['win'] for r in g) for g in groups);l=sum(all(r['loss'] for r in g) for g in groups)
  ranking.append(dict(config_hash=identity,eligible=e['eligible'],wins=w,losses=l,unresolved=n-w-l,scheduled=n,lower=w/n,completion=(w+l)/n,sources=e['sources']))
 ranking.sort(key=lambda r:(not r['eligible'],-r['lower'],-r['completion'],r['config_hash']))
 if not ranking:
  atomic_json(ROOT/'selection.json',dict(status='no completed exports',ranking=[]));return None
 best=entries[ranking[0]['config_hash']]['export']
 atomic_json(ROOT/'selection.json',dict(ranking=ranking,source_export=best,genome=best['genome'],diagnostic_only=not ranking[0]['eligible'],rule='Evolution-arm exports only; any training AND validation eligible export first, then unique validation candidate-game wins/scheduled, completion and stable config hash. Keep conflicting repeated observations conservative. No eligible export means diagnostic-only fallback. Random-control exports cannot become the selected evolved candidate.'))
 atomic_json(ROOT/'selected-genome.json',best['genome'])
 return best['genome']

def screen(depth,chosen,starts,cap):
 folder=ROOT/f'screen-depth{depth}'
 players=[candidate('selected',genome=chosen),candidate('flat-default',role='incumbent'),candidate('scaled-variable',genome=Genome.from_genes({'material':5},variable_material_enabled=True).to_dict(),role='archive')]
 spec=manifest(players,starts,[limits(depth)],pool='validation');atomic_json(folder/'manifest.json',spec)
 atomic_json(folder/'budget.json',dict(max_seconds=cap,max_games=len(spec['tasks']),max_reserved_work=len(spec['tasks'])*(20_000+spec['protocols'][0]['max_plies']*spec['protocols'][0]['search']['node_limit'])))
 cancel=threading.Event();old={sig:signal.signal(sig,lambda *_:cancel.set()) for sig in (signal.SIGINT,signal.SIGTERM)}
 timer=threading.Timer(cap,cancel.set);timer.daemon=True;timer.start();pool=EnginePool(3);rows=[];begin=time.monotonic()
 try:
  # Interleave opponents by opening/colour rather than spending the cap on one.
  for task in sorted(spec['tasks'],key=lambda t:(t['position'],t['index']%2,t['index'])):
   if cancel.is_set():break
   atomic_json(ROOT/'active.json',dict(phase='screen',depth=depth,task=task['index'],elapsed=time.monotonic()-START))
   row=play_match(spec,task,folder/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire);rows.append(row)
   print(json.dumps(dict(phase='screen_game',depth=depth,status=row['status'],index=task['index'])),flush=True)
 finally:
  timer.cancel();pool.close()
  for sig,handler in old.items():signal.signal(sig,handler)
 result=report(spec,rows);result['wall_seconds']=time.monotonic()-begin;atomic_json(folder/'report.json',result)
 return folder

def main():
 corpus=generate_positions(seed=3457,lines=120,max_plies=240);positions=[p for p in corpus if p['stage']=='endgame']
 atomic_json(ROOT/'corpus-full.json',corpus);atomic_json(ROOT/'corpus-endgames.json',positions)
 settings=Settings(population=3,generations=3,mutation_rate=.7,toggle_rate=.1,mutation_sigma=.05,random_off_rate=.2,near_default_fraction=2/3,search_positions=1,validation_positions=1,max_seconds=550,max_games=120,max_nodes=100_000_000_000,resident_engines=4,variable_material_enabled=True,initial_material=5)
 spec=prepare(settings,positions,limits(1),revision=REVISION)
 used_seeds={p['seed'] for p in positions if p['sha256'] in spec['validation']}
 fresh=sorted((p for p in positions if p['pool']=='validation' and p['seed'] not in used_seeds),key=lambda p:p['sha256'])
 starts2=fresh[:4];starts4=fresh[4:6];assert len(starts2)==4 and len(starts4)==2
 atomic_json(ROOT/'design.json',dict(revision=REVISION,master='2ac15df',settings=settings.to_dict(),protocols={str(d):limits(d) for d in (1,2,4)},seeds=[171,172],corpus=dict(seed=3457,lines=120,max_plies=240,pools=dict(Counter(p['pool'] for p in positions))),screen_positions={2:[p['sha256'] for p in starts2],4:[p['sha256'] for p in starts4]},budget=dict(total_seconds=3600,supervisor_seconds=3500,smoke_seconds=180,optimizer_runs=4,optimizer_seconds_each=550,depth2_screen_seconds=600,depth4_screen_seconds=400),selection='Evolution-arm completed exports only; eligibility first, then unique validation candidate-game wins/scheduled, completion and stable config hash. If none eligible, deeper screens diagnostic only. Random controls kept separate. Freeze selected genome before fresh deeper screens.',scope='Variable mode fixed true for all evolved genes; six weights -100..100, initial material5, REG.25 fixed. Official outcomes are fitness; consensus separate. Two seeds crossed with evolution/random identical ceilings and initialization. Fresh development-validation endgames, heldout never played; defaults unchanged.'))
 smoke=prepare(replace(settings,population=2,generations=1,max_seconds=180,max_games=16,max_nodes=3_000_000),positions,limits(1,True),revision=REVISION)
 atomic_json(ROOT/'active.json',dict(phase='smoke',elapsed=time.monotonic()-START))
 r=run(smoke,ROOT/'smoke');smoke_receipt(ROOT/'smoke',spec)
 folders=[];comparisons=[]
 for seed in (171,172):
  for algorithm in ('evolution','random'):
   trial=prepare(replace(settings,seed=seed,algorithm=algorithm),positions,limits(1),revision=REVISION)
   folder=ROOT/'runs'/f'{algorithm}-{seed}';atomic_json(ROOT/'active.json',dict(phase='optimization',arm=folder.name,elapsed=time.monotonic()-START))
   r=run(trial,folder,smoke=ROOT/'smoke');folders.append(folder)
   comparisons.append(dict(seed=seed,algorithm=algorithm,**{k:r[k] for k in ('status','generations','unique_candidates','unique_matches','games_reserved','nodes_reserved','measured_search_work','wall_seconds','known_child_cpu_seconds','failures','outcomes','eligible_exports')},convergence=r['convergence']))
   atomic_json(ROOT/'comparison.json',dict(runs=comparisons,note='Equal ceilings, not equal measured compute; repeated generations/cache hits are correlated.'))
   print(json.dumps(dict(phase='optimization_done',arm=folder.name,status=r['status'],generations=r['generations'],exports=r['eligible_exports'])),flush=True)
   if r['status']=='cancelled':raise RuntimeError('Optimizer interrupted')
 chosen=choose([p for p in folders if p.name.startswith('evolution')]);screens=[]
 if chosen:
  for depth,starts,cap in ((2,starts2,600),(4,starts4,400)):
   allowance=min(cap,max(1,3330-(time.monotonic()-START)))
   screens.append(screen(depth,chosen,starts,allowance))
 atomic_json(ROOT/'active.json',dict(phase='audit',elapsed=time.monotonic()-START))
 checks=[verify(p) for p in [ROOT/'smoke',*folders]]
 for folder in screens:
  m=json.loads((folder/'manifest.json').read_text());validate_manifest(m);rows=[json.loads(p.read_text()) for p in (folder/'matches').glob('*.json')]
  for row in rows:replay(next(p for p in m['positions'] if p['sha256']==row['task']['position']),row)
  saved=json.loads((folder/'report.json').read_text());rebuilt=report(m,rows);rebuilt['wall_seconds']=saved['wall_seconds'];assert rebuilt==saved
  checks.append(dict(run=str(folder),verified_matches=len(rows),verified_moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows))))
 atomic_json(ROOT/'verification.json',checks)
 consensus=[analyze(p,deadline=START+3430) for p in folders+screens]
 atomic_json(ROOT/'consensus.json',dict(runs=consensus))
 atomic_json(ROOT/'finished.json',dict(elapsed_seconds=time.monotonic()-START,status='complete'))
 print(json.dumps(dict(phase='finished',elapsed=time.monotonic()-START)),flush=True)
if __name__=='__main__':main()
