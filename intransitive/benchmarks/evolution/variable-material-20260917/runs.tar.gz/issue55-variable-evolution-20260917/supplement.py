"""Post-hoc check of a completion-rejected training leader; original results unchanged."""
import json,time,importlib.util
from pathlib import Path
from collections import Counter
from intransitive.tournament.runner import atomic_json,replay,validate_manifest
from intransitive.tournament.report import report
from intransitive.benchmarks.evolution.adjudicate import analyze
R=Path('/tmp/issue55-variable-evolution-20260917');born=(R/'supervisor.log').stat().st_birthtime
read=lambda p:json.loads(p.read_text())
specmod=importlib.util.spec_from_file_location('original_study',R/'study.py');m=importlib.util.module_from_spec(specmod);specmod.loader.exec_module(m)
state=read(R/'runs/evolution-171/checkpoint.json');board=state['history'][0]['search']['leaderboards']['depth']
rows=[r for r in board if r['role']=='population' and not r['eligible'] and not r['failures'] and r['wins']>r['losses'] and r['completion_rate']<.8]
rows.sort(key=lambda r:(-r['win_points_lower'],-r['completion_rate'],r['config_hash']))
design=read(R/'design.json');training=read(R/'runs/evolution-171/manifest.json');corpus=read(R/'corpus-endgames.json')
used=set(training['validation'])|{h for starts in design['screen_positions'].values() for h in starts};used_seeds={p['seed'] for p in corpus if p['sha256'] in used}
starts=sorted((p for p in corpus if p['pool']=='validation' and p['seed'] not in used_seeds),key=lambda p:p['sha256'])[:2];assert len(starts)==2
elapsed=time.time()-born;cap=min(300,3400-elapsed)
choice=dict(kind='post-hoc completion-gate diagnostic',rule='Seed171 generation0 candidates with more wins than losses, no failures, rejected for completion<.8; order by official wins/scheduled, completion, stable config hash. Selected after inspecting primary development results; not a replacement for original evolutionary selection.',elapsed_at_start=elapsed,max_seconds=cap,position_hashes=[p['sha256'] for p in starts],depth=2,game_seconds=20,comparison='Fresh development-validation lines against flat and scaled-variable baselines; no heldout or default adoption.')
if not rows or cap<180:
 choice.update(status='skipped',reason='No qualifying rejected candidate or less than180 seconds remain before3400-second game deadline');atomic_json(R/'supplement-selection.json',choice);raise SystemExit(0)
chosen=state['seen'][rows[0]['config_hash']];choice.update(status='scheduled',training=rows[0],genome=chosen);atomic_json(R/'supplement-selection.json',choice)
m.ROOT=R/'supplemental';m.START=time.monotonic()-elapsed
oldlimits=m.limits
def limits(depth,smoke=False):
 p=oldlimits(depth,smoke);p['game_seconds']=20;return p
m.limits=limits
folder=m.screen(2,chosen,starts,cap)
spec=read(folder/'manifest.json');validate_manifest(spec);journals=[read(p) for p in (folder/'matches').glob('*.json')]
for row in journals:replay(next(p for p in spec['positions'] if p['sha256']==row['task']['position']),row)
saved=read(folder/'report.json');rebuilt=report(spec,journals);rebuilt['wall_seconds']=saved['wall_seconds'];assert rebuilt==saved
checks=read(R/'verification.json');checks.append(dict(run=str(folder),verified_matches=len(journals),verified_moves=sum(len(r['moves']) for r in journals),outcomes=dict(Counter(r['status'] for r in journals))));atomic_json(R/'verification.json',checks)
cons=read(R/'consensus.json');cons['runs'].append(analyze(folder,deadline=time.monotonic()+max(1,3460-(time.time()-born))));atomic_json(R/'consensus.json',cons)
choice.update(status='complete',elapsed_at_end=time.time()-born);atomic_json(R/'supplement-selection.json',choice)
