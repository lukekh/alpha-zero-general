import json
from pathlib import Path
R=Path('/tmp/issue55-variable-evolution-20260917')
for name in ('progress.json','active.json','finished.json'):
 p=R/name
 if p.exists():
  r=json.loads(p.read_text())
  if name=='progress.json':r={k:r[k] for k in ('elapsed_seconds','peak_tree_rss_bytes','observed_priorities','priority_anomalies')}
  print(name,json.dumps(r))
for folder in [*sorted((R/'runs').glob('*')), *sorted(R.glob('screen-depth*'))]:
 if not folder.is_dir():continue
 p=folder/'checkpoint.json';report=folder/'report.json'
 if p.exists() and not report.exists():
  s=json.loads(p.read_text());print(folder.name,json.dumps({k:s.get(k) for k in ('generation','phase','games_reserved','wall_seconds','stop_reason')})+f" exports={len(s['exports'])}")
 if report.exists():
  r=json.loads(report.read_text());print(folder.name,'report',json.dumps({k:r.get(k) for k in ('status','generations','unique_matches','eligible_exports')}))
from collections import Counter
for folder in sorted(R.glob('screen-depth*')):
 if not folder.is_dir():continue
 spec=json.loads((folder/'manifest.json').read_text());selected=next(c['sha256'] for c in spec['candidates'] if c['name']=='selected');rows=[json.loads(p.read_text()) for p in (folder/'matches').glob('*.json')];counts=Counter()
 for row in rows:
  side=row['colours'].index(selected);counts[('win' if row['winner']==side else 'loss') if row['status']=='win' else row['status']]+=1
 print(folder.name,'candidate',dict(counts),'attempted',len(rows),'scheduled',len(spec['tasks']))

if (R/'focus-progress.json').exists():
 f=json.loads((R/'focus-progress.json').read_text());print('FOCUSED',{k:f[k] for k in ('elapsed_original_seconds','phase_seconds','peak_tree_rss_bytes','priorities','jobs')})
 for folder in sorted(R.glob('focused/*/screen-depth*')):
  spec=json.loads((folder/'manifest.json').read_text());selected=next(c['sha256'] for c in spec['candidates'] if c['name']=='selected');counts=Counter()
  for p in (folder/'matches').glob('*.json'):
   row=json.loads(p.read_text());side=row['colours'].index(selected);counts[('win' if row['winner']==side else 'loss') if row['status']=='win' else row['status']]+=1
  print(str(folder.relative_to(R)),dict(counts))
