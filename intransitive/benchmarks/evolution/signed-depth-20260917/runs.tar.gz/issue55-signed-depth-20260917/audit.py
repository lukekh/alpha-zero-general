import json
from pathlib import Path
from collections import Counter
from intransitive.benchmarks.evolution.verify import verify
from intransitive.tournament.runner import validate_manifest,replay,atomic_json
from intransitive.tournament.report import report
ROOT=Path('/tmp/issue55-signed-depth-20260917')
audits=[];arms=[];all_rows=[];keys=set();trajectories=set();configs=set()
for folder in sorted(list(ROOT.glob('smoke-*'))+list((ROOT/'runs').glob('*'))):
 if not (folder/'report.json').exists():continue
 audits.append(verify(folder));cp=json.loads((folder/'checkpoint.json').read_text());summary=json.loads((folder/'report.json').read_text())
 for key,entry in cp['ledger'].items():
  row=json.loads((folder/entry['record']).read_text());all_rows.append(row)
  if not folder.name.startswith('smoke-'):keys.add(key);trajectories.add(row['trajectory_sha256'])
 if not folder.name.startswith('smoke-'):configs.update(cp['seen'])
 arms.append(dict(name=folder.name,summary=summary,exports=cp['exports'],partial_current=cp.get('current')))
atomic_json(ROOT/'verification.json',audits)
screens=[];screen_audits=[]
for folder in sorted((ROOT/'screens').glob('*')):
 selection=json.loads((folder/'selection.json').read_text())
 if not (folder/'report.json').exists():
  screens.append(dict(name=folder.name,selection=selection,report=None));continue
 spec=json.loads((folder/'manifest.json').read_text());validate_manifest(spec)
 rows=sorted([json.loads(p.read_text()) for p in (folder/'matches').glob('*.json')],key=lambda r:r['task']['index'])
 for row in rows:
  assert row['manifest_sha256']==spec['sha256'] and row['task'] in spec['tasks'] and row['colours']==row['task']['colours']
  start=next(p for p in spec['positions'] if p['sha256']==row['task']['position']);replay(start,row)
 saved=json.loads((folder/'report.json').read_text());rebuilt=report(spec,rows);rebuilt['wall_seconds']=saved['wall_seconds'];assert saved==rebuilt
 screens.append(dict(name=folder.name,selection=selection,report=saved));all_rows.extend(rows)
 screen_audits.append(dict(name=folder.name,records=len(rows),moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows))))
atomic_json(ROOT/'screen-verification.json',screen_audits)
violations=[]
for row in all_rows:
 for m in row['moves']:
  result=m['result']
  if result.get('search_kind')=='mcts':
   if result['completed_simulations']!=result['requested_simulations'] or result['stopped']:violations.append(row['task']['id'])
  elif result['stopped'] or result['selection_source']!='completed_iteration':violations.append(row['task']['id'])
assert not violations
summary=dict(design=json.loads((ROOT/'design.json').read_text()),measurements=json.loads((ROOT/'measurements.json').read_text()),arms=arms,screens=screens,total_records=len(all_rows),outcomes=dict(Counter(r['status'] for r in all_rows)),comparison_identity=dict(distinct_matches=len(keys),distinct_trajectories=len(trajectories),distinct_configurations=len(configs)),played_search_completion_violations=violations)
atomic_json(ROOT/'summary.json',summary)
print(json.dumps(dict(verified_optimizer_records=sum(x['verified_matches'] for x in audits),verified_screen_records=sum(x['records'] for x in screen_audits),total_records=len(all_rows),played_search_completion_violations=len(violations))))
