import os
os.setpriority(os.PRIO_PROCESS,0,19)
import json,time,signal,threading,subprocess
from pathlib import Path
import numpy as np
from intransitive.tournament.spec import position,replay_opening,protocol,candidate,manifest
from intransitive.tournament.runner import atomic_json,play_match
from intransitive.tournament.report import report
from intransitive.evolution.engines import EnginePool
from intransitive.heuristics.tuning import Genome
from intransitive.IntransitiveGame import IntransitiveGame
from intransitive.IntransitiveConstants import action_destination
ROOT=Path('/tmp/issue55-signed-depth-20260917');OUT=ROOT/'supplement'
# The original launch timestamp, not a fresh hour for this supplement.
DEADLINE=(ROOT/'supervisor.log').stat().st_birthtime+3540

def main():
 if time.time()+130>DEADLINE:
  atomic_json(OUT/'skipped.json',dict(reason='Insufficient original one-hour budget'));return
 corpus=json.loads((ROOT/'corpus-endgames.json').read_text());design=json.loads((ROOT/'design.json').read_text())
 used=set(design['screen_positions'])|set(json.loads((ROOT/'inputs/minimax-d1.json').read_text())['validation'])
 originals=sorted((p for p in corpus if p['pool']=='validation' and p['sha256'] not in used),key=lambda p:p['sha256'])
 game=IntransitiveGame(modelling_draws=False);start=None;attempts=[]
 for original in originals:
  state=replay_opening(original['opening_actions']);side=len(original['opening_actions'])%2;actions=list(original['opening_actions']);rng=np.random.default_rng(original['seed']+100000)
  for _ in range(160):
   legal=list(map(int,np.flatnonzero(game.getValidMoves(state,side))))
   if not legal:break
   captures=[a for a in legal if state[action_destination(a)[1],action_destination(a)[0],0]]
   a=int(rng.choice(captures if captures and rng.random()<.9 else legal));state,side=game.getNextState(state,side,a);actions.append(a)
   if game.getGameEnded(state,side).any():break
   if np.count_nonzero(state[:,:,0])<=8:
    start=position(actions,seed=original['seed'],stage='endgame',pool='validation');break
  attempts.append(dict(original=original['sha256'],seed=original['seed'],found=start is not None))
  if start is not None:break
 if start is None:
  atomic_json(OUT/'skipped.json',dict(reason='No bounded legal eight-piece continuation',attempts=attempts));return
 choices={}
 for name in ('minimax-d2','minimax-d3','minimax-d1','mcts-s32','mcts-s128'):
  selection=json.loads((ROOT/'screens'/name/'selection.json').read_text())
  if 'genome' in selection:genome=selection['genome'];source='Exact primary-screen selection, including diagnostic-only selections'
  elif name=='minimax-d2':
   current=json.loads((ROOT/'runs/minimax-d2-91/checkpoint.json').read_text())['current']
   genome=next(g for g in current['population'] if Genome.from_json(json.dumps(g)).config_hash==current['ranking'][0]);source='Training-only ranking winner from depth-two seed91; validation interrupted, no completed export'
  elif name=='mcts-s128':
   fallback=json.loads((ROOT/'screens/mcts-s32/selection.json').read_text())
   if 'genome' not in fallback:continue
   genome=fallback['genome'];source='Transfer test of exact MCTS32 selection at MCTS128; no completed MCTS128 export'
  else:continue
  choices[name]=dict(genome=genome,source=source)
 atomic_json(OUT/'design.json',dict(diagnostic_only=True,purpose='Explore compute-limited settings on one simpler fresh legal line; no re-evolution and no acceptance claim',position=start,continuation_attempts=attempts,choices=choices,original_launch_unix=(ROOT/'supervisor.log').stat().st_birthtime,deadline_unix=DEADLINE,per_setting_seconds=100,selection_rule='Reuse primary selections; missing depth2 uses completed seed91 training ranking; missing MCTS128 transfers the MCTS32 selection. Prioritize depth2 then depth3, depth1, MCTS32, MCTS128. One common unused validation line continued legally to eight pieces, selected without outcomes.'))
 cancel=threading.Event()
 for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:cancel.set())
 for name,choice in choices.items():
  remaining=DEADLINE-time.time()
  if remaining<115 or cancel.is_set():break
  mode='mcts' if name.startswith('mcts') else 'depth';n=int(name.rsplit('s' if mode=='mcts' else 'd',1)[1])
  limits=protocol(mode,depth=n if mode=='depth' else 1,simulations=n if mode=='mcts' else 32,seconds=8,node_limit=20_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=30)
  spec=manifest([candidate('selected',genome=choice['genome']),candidate('adopted-default')],[start],[limits],pool='validation');folder=OUT/name
  atomic_json(folder/'manifest.json',spec);atomic_json(folder/'selection.json',choice)
  pool=EnginePool(2);rows=[];begin=time.monotonic();timer=threading.Timer(100,cancel.set);timer.daemon=True;timer.start()
  try:
   for task in spec['tasks']:
    if cancel.is_set():break
    row=play_match(spec,task,folder/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire);rows.append(row)
    print(json.dumps(dict(setting=name,index=task['index'],status=row['status'])),flush=True)
  finally:timer.cancel();pool.close()
  result=report(spec,rows);result['wall_seconds']=time.monotonic()-begin;atomic_json(folder/'report.json',result)
  if time.time()+115<DEADLINE:cancel.clear()
 atomic_json(OUT/'finished.json',dict(original_elapsed_seconds=time.time()-(ROOT/'supervisor.log').stat().st_birthtime))
if __name__=='__main__':main()
