import json,subprocess,time
from pathlib import Path
ROOT=Path('/tmp/issue55-signed-depth-20260917')
measurements=[];ids=set()
for folder in (ROOT,ROOT/'supplement',ROOT/'postprocess'):
 d=json.loads((folder/'measurements.json').read_text());measurements.append(dict(folder=str(folder),measurement=d))
 for phase in d['phases']:ids.update(phase['observed_pids'])
snapshot=subprocess.check_output(['ps','-axo','pid=,ppid=,ni=,stat=,args='],text=True)
rows=[]
for line in snapshot.splitlines():
 bits=line.split(None,4)
 if len(bits)==5 and int(bits[0]) in ids:rows.append(dict(pid=int(bits[0]),ppid=int(bits[1]),nice=int(bits[2]),state=bits[3],args=bits[4]))
result=dict(original_elapsed_seconds=time.time()-(ROOT/'supervisor.log').stat().st_birthtime,observed_experiment_pids_still_present=rows,measurements=measurements,note='Read-only PID check after all three supervisors exited. No signals sent to training jobs. Report preparation and archiving follow this receipt.')
(ROOT/'cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(elapsed=result['original_elapsed_seconds'],still_present=rows,phases=[dict(folder=m['folder'],seconds=m['measurement']['elapsed_seconds'],peak_rss=max(p['peak_sampled_tree_rss_bytes'] for p in m['measurement']['phases']),priorities=m['measurement']['phases'][0]['observed_priorities']) for m in measurements])))
