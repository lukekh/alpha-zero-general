import json
from pathlib import Path
from collections import Counter
ROOT=Path('/tmp/issue55-signed-depth-20260917')
cons=json.loads((ROOT/'consensus.json').read_text());rows=[]
for run in cons['runs']:
 folder=Path(run['folder'])
 if folder.parent.name!='runs':continue
 cp=json.loads((folder/'checkpoint.json').read_text());adjudications={x['match_key']:x for x in run['matches']}
 stages=list(cp['history'])+([cp['current']] if cp.get('current') else [])
 for stage in stages:
  if not stage.get('search'):continue
  config_by_candidate={}
  for b in stage['search']['leaderboards'].values():
   config_by_candidate.update({e['candidate']:e['config_hash'] for e in b})
  tally={k:Counter() for k in stage['ranking']}
  for key in stage['search']['match_keys']:
   row=json.loads((folder/cp['ledger'][key]['record']).read_text());result=adjudications[key]
   for side,identity in enumerate(row['colours']):
    config=config_by_candidate[identity]
    if config not in tally:continue
    t=tally[config];t['scheduled']+=1;winner=result['effective_winner']
    if winner is not None:t['wins' if winner==side else 'losses']+=1
    else:t['inconclusive_or_excluded']+=1
  ranking=[]
  for config,t in tally.items():
   n=t['wins']+t['losses'];ranking.append(dict(config_hash=config,**dict(t),decided=n,fraction=t['wins']/n if n else None,genome=cp['seen'][config]))
  ranking.sort(key=lambda r:(-(r['fraction'] if r['fraction'] is not None else -1),-r['decided'],r['config_hash']))
  rows.append(dict(arm=folder.name,generation=stage['generation'],original_first=stage['ranking'][0],consensus_first=ranking[0]['config_hash'],changed=stage['ranking'][0]!=ranking[0]['config_hash'],ranking=ranking))
(ROOT/'consensus-training-ranking.json').write_text(json.dumps(dict(note='Post-hoc re-ranking of completed training batches only; official optimizer populations, fitness, eligibility and exports unchanged. Inconclusive and failed games excluded from decided fraction, tie break more decided games then hash. Does not recreate an optimizer bred under this rule.',batches=rows),indent=2)+'\n')
for r in rows:print(r['arm'],r['generation'],'changed',r['changed'],r['ranking'][0]['genome']['genes'])
