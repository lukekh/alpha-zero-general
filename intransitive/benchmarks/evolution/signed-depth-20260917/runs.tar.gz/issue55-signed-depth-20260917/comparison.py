import json,csv
from pathlib import Path
ROOT=Path('/tmp/issue55-signed-depth-20260917')
def read(p):return json.loads(p.read_text())
output=dict(arms=[],screens=[],supplement=[])
for folder in sorted((ROOT/'runs').glob('*')):
 r=read(folder/'report.json');exports=read(folder/'candidates.json')
 row={k:r[k] for k in ('status','generations','unique_candidates','unique_matches','eligible_exports','outcomes','measured_search_work','known_child_cpu_seconds','wall_seconds')};row['name']=folder.name
 row['exports']=[dict(generation=e['generation'],genes=e['genome']['genes'],eligible=e['eligible'],search={k:e['search'][k] for k in ('eligible','wins','losses','unfinished','failures','scheduled')},validation={k:e['validation'][k] for k in ('eligible','wins','losses','unfinished','failures','scheduled')}) for e in exports]
 output['arms'].append(row)
for section,root in [('screens',ROOT/'screens'),('supplement',ROOT/'supplement')]:
 for folder in sorted(root.glob('*')):
  if not (folder/'selection.json').exists():continue
  selection=read(folder/'selection.json');row=dict(name=folder.name,genes=selection.get('genome',{}).get('genes'),diagnostic_only=section=='supplement' or selection.get('diagnostic_only',True))
  if (folder/'report.json').exists():
   r=read(folder/'report.json');board=next(iter(r['leaderboards'].values()));candidate=next(c for c in board if c['name']=='selected')
   row.update({k:candidate[k] for k in ('wins','losses','unfinished','failures','pending','scheduled','eligible','paired_interval_95','completed_depths','completed_simulations','observed_tree_depths','statuses','work','search_wall_seconds')})
  else:row['status']=selection.get('status','no report')
  output[section].append(row)
genomes={}
for folder in (ROOT/'runs').glob('*'):genomes.update(read(folder/'checkpoint.json')['seen'])
output['registered_gene_ranges']={g:[min(v['genes'][g] for v in genomes.values()),max(v['genes'][g] for v in genomes.values())] for g in next(iter(genomes.values()))['genes']}
output['registered_configurations_including_references']=len(genomes)
(ROOT/'comparison.json').write_text(json.dumps(output,indent=2)+'\n')
for section in ('arms','screens','supplement'):
 rows=output[section]
 print(section)
 for row in rows:print(json.dumps({k:v for k,v in row.items() if k not in ('exports','completed_depths','completed_simulations','observed_tree_depths')}))
