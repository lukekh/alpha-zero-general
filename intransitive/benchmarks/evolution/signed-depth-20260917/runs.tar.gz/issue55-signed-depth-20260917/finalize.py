import json,subprocess,sys,time
from pathlib import Path
ROOT=Path('/tmp/issue55-signed-depth-20260917')
for script in ('audit.py','audit-supplement.py'):
 subprocess.run([sys.executable,str(ROOT/script)],check=True)
folders=[p for p in sorted((ROOT/'screens').glob('*')) if (p/'report.json').exists()]
folders += [p for p in sorted((ROOT/'supplement').glob('*')) if (p/'report.json').exists()]
folders += sorted((ROOT/'runs').glob('*'))
folders += [ROOT/'smoke-depth',ROOT/'smoke-mcts']
remaining=(ROOT/'supervisor.log').stat().st_birthtime+3500-time.time()
assert remaining>15
subprocess.run([sys.executable,'-m','intransitive.benchmarks.evolution.adjudicate',*[str(p) for p in folders],
 '--max-seconds',str(min(120,remaining)),'--output',str(ROOT/'consensus.json')],check=True)
subprocess.run([sys.executable,str(ROOT/'comparison.py')],check=True)
