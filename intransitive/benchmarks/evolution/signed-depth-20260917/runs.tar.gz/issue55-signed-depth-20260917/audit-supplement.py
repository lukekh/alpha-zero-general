import json
from pathlib import Path
from collections import Counter
from intransitive.tournament.runner import validate_manifest,replay,atomic_json
from intransitive.tournament.report import report
ROOT=Path('/tmp/issue55-signed-depth-20260917/supplement');results=[]
for folder in sorted(ROOT.glob('*')):
 if not (folder/'report.json').exists():continue
 spec=json.loads((folder/'manifest.json').read_text());validate_manifest(spec)
 rows=sorted((json.loads(p.read_text()) for p in (folder/'matches').glob('*.json')),key=lambda r:r['task']['index'])
 for row in rows:
  assert row['manifest_sha256']==spec['sha256'] and row['task'] in spec['tasks'] and row['colours']==row['task']['colours']
  start=next(p for p in spec['positions'] if p['sha256']==row['task']['position']);replay(start,row)
  for move in row['moves']:
   result=move['result'];assert not result['stopped']
   if result.get('search_kind')=='mcts':assert result['completed_simulations']==result['requested_simulations']
   else:assert result['selection_source']=='completed_iteration'
 saved=json.loads((folder/'report.json').read_text());rebuilt=report(spec,rows);rebuilt['wall_seconds']=saved['wall_seconds'];assert rebuilt==saved
 results.append(dict(name=folder.name,records=len(rows),moves=sum(len(r['moves']) for r in rows),outcomes=dict(Counter(r['status'] for r in rows))))
atomic_json(ROOT/'verification.json',results)
print(json.dumps(results))
