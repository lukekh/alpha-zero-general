import time
START=time.monotonic()
import json,signal,threading,subprocess
from pathlib import Path
from dataclasses import replace
from collections import Counter
from intransitive.evolution.runner import prepare,run,smoke_receipt
from intransitive.evolution.strategy import Settings
from intransitive.evolution.engines import EnginePool
from intransitive.tournament.spec import candidate,manifest,protocol,generate_positions
from intransitive.tournament.runner import atomic_json,play_match
from intransitive.tournament.report import report
ROOT=Path('/tmp/issue55-signed-depth-20260917')
REVISION=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()

def screen(name,folders,spec,starts):
 output=ROOT/'screens'/name;default=candidate('adopted-default');entries={}
 for folder in folders:
  for export in json.loads((folder/'candidates.json').read_text()):
   identity=export['manifest']['config_hash'];e=entries.setdefault(identity,dict(export=export,eligible_training=False,observations={},sources=[]))
   e['eligible_training'] |= export['search']['eligible'];e['sources'].append(dict(arm=folder.name,generation=export['generation'],training_eligible=export['search']['eligible']))
   for key in export['validation_match_keys']:
    row=json.loads((folder/'matches'/key/'game.json').read_text());who=export['validation']['candidate']
    if who not in row['colours'] or default['sha256'] not in row['colours']:continue
    colour=row['colours'].index(who)
    e['observations'].setdefault(key,[]).append(dict(win=row['status']=='win' and row['winner']==colour,loss=row['status']=='win' and row['winner']!=colour))
 ranking=[]
 for identity,e in entries.items():
  groups=list(e['observations'].values());n=len(groups)
  if not n:continue
  w=sum(all(r['win'] for r in g) for g in groups);l=sum(all(r['loss'] for r in g) for g in groups)
  active=sum(e['export']['genome']['genes'][g]!=0 for g in ('attack','defence','overload','pressure'))
  ranking.append(dict(config_hash=identity,eligible_training=e['eligible_training'],wins=w,losses=l,unresolved=n-w-l,scheduled=n,lower=w/n,completion=(w+l)/n,active_optional=active,sources=e['sources']))
 ranking.sort(key=lambda r:(not r['eligible_training'],-r['lower'],-r['completion'],r['active_optional'],r['config_hash']))
 if not ranking:
  atomic_json(output/'selection.json',dict(status='no completed candidate export',ranking=[]));return
 best=entries[ranking[0]['config_hash']]['export'];limits=spec['limits']
 chosen=candidate('selected',genome=best['genome']);match=manifest([chosen,default],starts,[limits],pool='validation')
 atomic_json(output/'selection.json',dict(ranking=ranking,source_export=best,genome=best['genome'],selection_rule='Completed exports; candidate with any eligible training first, then conservative direct-default validation wins over unique full match keys, completion, fewer enabled optional modules, config hash. Retain all validation records, including from ineligible exports. If no training-eligible export exists, final screen is diagnostic only.',diagnostic_only=not ranking[0]['eligible_training']))
 atomic_json(output/'manifest.json',match);atomic_json(output/'genome.json',best['genome']);atomic_json(output/'budget.json',dict(max_seconds=130,max_games=8,max_reserved_work=8*(20_000+limits['max_plies']*limits['search']['node_limit'])))
 cancel=threading.Event();old={}
 for sig in (signal.SIGINT,signal.SIGTERM):old[sig]=signal.signal(sig,lambda *_:cancel.set())
 begin=time.monotonic();timer=threading.Timer(130,cancel.set);timer.daemon=True;timer.start();pool=EnginePool(2);rows=[]
 try:
  for task in match['tasks']:
   if cancel.is_set():break
   row=play_match(match,task,output/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire);rows.append(row)
   print(json.dumps(dict(phase='screen',setting=name,index=task['index'],status=row['status'])),flush=True)
 finally:
  timer.cancel();pool.close()
  for sig,handler in old.items():signal.signal(sig,handler)
 result=report(match,rows);result['wall_seconds']=time.monotonic()-begin
 atomic_json(output/'report.json',result)

def main():
 corpus=generate_positions(seed=901,lines=120,max_plies=240);positions=[p for p in corpus if p['stage']=='endgame']
 atomic_json(ROOT/'corpus-full.json',corpus);atomic_json(ROOT/'corpus-endgames.json',positions)
 settings=Settings(population=2,generations=2,mutation_rate=.7,toggle_rate=.1,mutation_sigma=.15,random_off_rate=.2,search_positions=1,validation_positions=1,max_seconds=240,max_games=64,max_nodes=80_000_000_000,resident_engines=4)
 configs={f'minimax-d{d}':protocol('depth',depth=d,seconds=4,node_limit=5_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=12) for d in (1,2,3)}
 configs.update({f'mcts-s{n}':protocol('mcts',depth=1,simulations=n,seconds=4,node_limit=5_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=12) for n in (32,128)})
 specs={name:prepare(settings,positions,limits,revision=REVISION) for name,limits in configs.items()}
 used=set(next(iter(specs.values()))['validation']);starts=sorted((p for p in positions if p['pool']=='validation' and p['sha256'] not in used),key=lambda p:p['sha256'])[:4]
 assert len(starts)==4
 atomic_json(ROOT/'design.json',dict(revision=REVISION,settings=settings.to_dict(),protocols=configs,seeds=[91,92],corpus=dict(seed=901,lines=120,max_plies=240,pools=dict(Counter(p['pool'] for p in positions))),screen_positions=[p['sha256'] for p in starts],budget=dict(total_seconds=3600,supervisor_deadline_seconds=3500,smoke_runs=2,smoke_seconds_each=180,optimizer_runs=10,optimizer_seconds_each=240,final_screens=5,screen_seconds_each=130),selection_rule='Completed exports; candidate with any eligible training first; then unique direct-default validation wins/scheduled, completion, fewer active optional modules, stable config identity. All validation observations retained; diagnostic-only fallback if none training-eligible.',scope='Two-seed evolution at each search setting; no random-search control in this expanded allocation. Common fresh screen positions; methods/depths never pooled. Defaults adopted separately by explicit user instruction; new exports provisional.'))
 for name,spec in specs.items():atomic_json(ROOT/'inputs'/(name+'.json'),spec)
 for mode in ('depth','mcts'):
  smoke_settings=Settings(population=2,generations=1,search_positions=1,max_seconds=180,max_games=16,max_nodes=3_000_000)
  smoke_limits=protocol(mode,depth=1,seconds=5,node_limit=50_000,proof_depth=0,proof_nodes=0,max_plies=2,game_seconds=15,simulations=4)
  spec=prepare(smoke_settings,positions,smoke_limits,revision=REVISION)
  print(json.dumps(dict(phase='smoke',mode=mode)),flush=True)
  r=run(spec,ROOT/('smoke-'+mode));smoke_receipt(ROOT/('smoke-'+mode),spec)
  print(json.dumps(dict(phase='smoke_done',mode=mode,status=r['status'],seconds=r['wall_seconds'])),flush=True)
 for name,base in specs.items():
  for seed in (91,92):
   spec=prepare(replace(settings,seed=seed),positions,base['limits'],revision=REVISION)
   atomic_json(ROOT/'active.json',dict(phase='search',setting=name,seed=seed,elapsed=time.monotonic()-START))
   r=run(spec,ROOT/'runs'/f'{name}-{seed}',smoke=ROOT/('smoke-'+base['limits']['mode']))
   print(json.dumps(dict(phase='run_done',setting=name,seed=seed,**{k:r[k] for k in ('status','generations','unique_matches','eligible_exports','wall_seconds')})),flush=True)
   if r['status']=='cancelled':return
 for name,base in specs.items():
  atomic_json(ROOT/'active.json',dict(phase='screen',setting=name,elapsed=time.monotonic()-START))
  screen(name,[ROOT/'runs'/f'{name}-{s}' for s in (91,92)],base,starts)
 atomic_json(ROOT/'finished.json',dict(elapsed=time.monotonic()-START,status='complete'))
 print(json.dumps(dict(phase='complete',elapsed=time.monotonic()-START)),flush=True)
if __name__=='__main__':main()
