import json
from pathlib import Path
ROOT=Path('/tmp/issue55-signed-depth-20260917');OUT=Path('intransitive/benchmarks/evolution/signed-depth-20260917');p=OUT/'README.md';s=p.read_text()
c=json.loads((ROOT/'comparison.json').read_text());clean=json.loads((ROOT/'cleanup.json').read_text())
results='''**No stronger replacement was established. Keep the adopted defaults.** The
same challenger A was selected at Minimax depth one and MCTS32; the deeper
Minimax selections used B, but were training-only or ineligible. Neither
MCTS128 seed completed an export. These differences do not establish optimal
weights that vary with depth.

| Vector | Material | Advantage | Attack | Defence | Overload | Pressure |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| A | 62.641359 | 23.967050 | 25.714517 | 18.275587 | 52.472203 | −84.631747 |
| B | −56.672198 | 53.275799 | 0 | −10.287148 | −39.597764 | 92.016227 |

Values above are rounded for display; exact genomes are in the archive and
[comparison](comparison.json). Primary fresh-screen outcomes below are from the
challenger's perspective. Consensus results use the user's later requested rule.

| Main setting | Vector | Official W / L / unfinished | After consensus W / L / inconclusive | Limit |
| --- | --- | --- | --- | --- |
| Minimax depth 1 | A | 0 / 7 / 1 | 0 / 8 / 0 | Four fresh paired lines |
| Minimax depth 2 | — | — | — | No completed export before wall cap |
| Minimax depth 3 | B | — | — | All eight games rejected for incomplete depth |
| MCTS 32 simulations | A | 0 / 3 / 5 | 0 / 5 / 3 | Diagnostic: no eligible training export |
| MCTS 128 simulations | — | — | — | No completed export before wall cap |

Both depth-one and both depth-three arms completed two generations. Each MCTS32
arm completed one; depth two and MCTS128 completed none. Generation completion
is not search eligibility: depth three's generations contain mostly rejected
moves. Observed MCTS tree depths across the optimizer runs were 1–8 at 32
simulations and 1–9 at 128; every played MCTS move completed its full requested
simulation count.

| Arm | Completed generations | Configurations¹ | Games | Official finishes² | Unfinished | Incomplete depth | Cancelled | Work (million) | Known child CPU (s) | Wall (s) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
for a in sorted(c['arms'],key=lambda x:(not x['name'].startswith('minimax'),x['name'])):
 o=a['outcomes'];results+=f"| {a['name']} | {a['generations']} | {a['unique_candidates']} | {a['unique_matches']} | {o['win']} | {o['unfinished']} | {o['depth_incomplete']} | {o['cancelled']} | {a['measured_search_work']/1e6:.2f} | {a['known_child_cpu_seconds']:.2f} | {a['wall_seconds']:.2f} |\n"
results+='''
¹ Includes two fixed reference configurations. Only **nine distinct registered
configurations** occur across all ten arms; shared initialization and short runs
make this a very sparse sample of the permitted six-dimensional box. Recorded
per-gene ranges are in `comparison.json`; permitting −100…100 does not mean this
small search thoroughly covers that range.

² Official finishes count either side winning, not challenger wins. The ten arms
contain 205 journal records, 195 distinct full match identities and 147 distinct
physical trajectories. Timing changes can produce distinct records for the same
logical match across arms; these are not independent evidence. Complete
per-generation populations, diversity, preflights, rankings, uncertainty and
per-opponent/colour statistics remain in the archive.
'''
s=s.replace('<!-- RESULTS -->',results)
supp='''## Remaining-budget diagnostic

After the main study, the remaining allocation was used for one common unused
validation line (seed **915**), legally continued to **eight pieces** without
consulting candidate outcomes. The continuation is bounded to 160 moves per
source line; the full original history and split are preserved. The choices
were frozen before these games: A at depth one/MCTS32; B at depth two from its
completed seed91 training ranking and at depth three from the main diagnostic
selection. With no MCTS128 export, A was transferred from MCTS32 without retuning.

Each setting has two games with colours swapped, at most 100 wall seconds,
eight seconds / 20 million work units per move, and 30 active game seconds /
192 plies. These are different caps and a different corpus from the primary
screens; their results are not pooled with those screens.

| Diagnostic setting | Vector | Official W / L / unfinished | After consensus W / L / inconclusive |
| --- | --- | --- | --- |
| Minimax depth 1 | A | 0 / 1 / 1 | 0 / 2 / 0 |
| Minimax depth 2 | B | 1 / 1 / 0 | 1 / 1 / 0 |
| Minimax depth 3 | B | 0 / 1 / 1 | 1 / 1 / 0 |
| MCTS 32 simulations | A | 0 / 1 / 1 | 0 / 1 / 1 |
| MCTS 128 simulations | A (transfer) | 0 / 1 / 1 | 0 / 2 / 0 |

All ten diagnostic games used completed requested searches; none was rejected
for incomplete depth/simulations. One paired opening cannot establish a strength
gain or a depth-specific optimum. Its 95% paired interval is [0, 1] at each setting.

## Consensus adjudication requested during the run

Both **competing weight configurations** score the same final legal board from
player zero's perspective, using static weighted evaluation with tree/proof
search disabled. If both scores are strictly positive, player zero wins by
adjudication; if both are negative, player one does. Ties, disagreement and
budget exhaustion stay inconclusive. Scores use a two-second / five-million-work
cap per evaluator. Official wins are retained. Nonempty legal prefixes stopped
by the game or overall wall cap may be adjudicated; crashes, illegal moves,
incomplete-depth failures and empty cancellations are excluded.

All **271 records** were analyzed, including the smokes for audit completeness:
92 official wins, **56 consensus wins**, 44 inconclusive and 79 excluded. Ten
consensus wins are two-ply smoke artifacts, leaving **46 additional non-smoke
adjudications**. This is an accounting total, not a pooled strength estimate.
All score pairs, original statuses, final-state hashes and alternative rankings
are in [consensus.json](consensus.json). No evaluator exceeded its scoring budget.

The alternative rankings exclude inconclusive games from the decided-game win
fraction, with conservative wins/scheduled also shown. Re-ranking the 11
completed training batches changes the first-ranked genome in two batches;
[full details](consensus-training-ranking.json) retain the original ranking.
This analysis does **not** recreate the breeding sequence of an optimizer that
used consensus from the start. Journals, original fitness, eligibility and
exports were not rewritten; no new defaults were adopted. Agreement between
related heuristics is an adjudication convention, not proof of the official
winner or an independent held-out assessment.
'''
s=s.replace('<!-- SUPPLEMENT -->',supp)
measure='''## Resource measurements and cleanup

The main supervisor ran **2527.22 seconds (42m07s)**; the diagnostic ran
**258.54 seconds (4m19s)**. Audits and adjudication took **33.42 seconds** in the
final supervised phase (adjudication itself 10.30 seconds). Including the gaps
between phases, cleanup confirmed no recorded experiment PID remained at
**2898.80 seconds (48m19s)** after the original launch, within the one-hour cap.
Report preparation and archiving follow this receipt.

Supervisors used nice 19, with OPENBLAS/OMP/MKL threads fixed to one. Three-second
sampling observed peak simultaneous descendant RSS of **539.7 MiB** in the main
study, **490.9 MiB** in the diagnostic and **274.6 MiB** during audit/analysis.
These are sampled process-tree sums, not exact peaks. Known child CPU excludes
work lost when children are killed; wall time includes startup and waiting on
the authorized shared machine.

The primary monitor observed one transient row at 481.62 seconds with nice 0,
zero RSS, state `?E` and command `(python3.11)`. Its attempt to lower that own
descendant's priority got `ProcessLookupError`: the PID was already absent.
All other sampled descendants were nice 19; the later phases sampled only 19.
The exact anomaly is preserved rather than claiming every sample had nice 19.
No crashes, illegal moves or infrastructure timeouts occurred. Six overall-cap
cancellations and 76 incomplete-depth records remain explicit in primary
outcomes. Training jobs were not changed.
'''
s=s.replace('<!-- MEASUREMENTS -->',measure)
evidence='''All **271 journals / 16,496 played moves** replayed successfully (261 primary,
10 diagnostic), with zero played-search completion violations. The consensus
analysis adds four passing tests for common-perspective scoring, immutable
journals, abstention and failure exclusion. Its source hash and backend fingerprint
are recorded in the analysis output.

- [Compact comparison](comparison.json), [frozen design](design.json)
- [Full primary summary](summary.json), [primary replay audit](verification.json)
- [Main-screen audit](screen-verification.json), [diagnostic audit](supplement-verification.json)
- [Consensus scores and rankings](consensus.json), [training re-ranking](consensus-training-ranking.json)
- [Measurements and cleanup receipt](cleanup.json)
- [Full archive](runs.tar.gz) and [SHA-256](runs.sha256): frozen scripts, inputs,
  complete journals/manifests/checkpoints/exports, tests and monitor logs

To replay/audit the archived data without starting engines, extract the archive
and use the saved `audit.py` and `audit-supplement.py` scripts after updating their
output-root paths. The primary evaluator fingerprint is unchanged by the
separate benchmark-analysis module. The original implementation is `9424a35`;
the consensus tool was introduced in `05fdaee` and includes its final source hash.
'''
s=s.replace('<!-- EVIDENCE -->',evidence)
p.write_text(s)
