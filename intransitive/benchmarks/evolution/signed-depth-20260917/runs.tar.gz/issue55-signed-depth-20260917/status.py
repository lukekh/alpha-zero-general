import json
from pathlib import Path
from collections import Counter
root=Path('/tmp/issue55-signed-depth-20260917')
p=json.loads((root/'progress.json').read_text());print(json.dumps({k:p[k] for k in ('elapsed_seconds','peak_tree_rss_bytes','observed_priorities','priority_anomalies')}))
for folder in sorted(list(root.glob('smoke-*'))+list((root/'runs').glob('*'))):
 f=folder/'checkpoint.json'
 if not f.exists():continue
 s=json.loads(f.read_text());exports=s['exports'][-1:] if not (folder/'report.json').exists() else []
 print(json.dumps(dict(arm=folder.name,phase=s['phase'],generation=s['generation'],attempts=s['games_reserved'],stop=s.get('stop_reason'),outcomes=dict(Counter(x['status'] for x in s['ledger'].values())),exports=[dict(genes=e['genome']['genes'],eligible=e['eligible'],validation={k:e['validation'][k] for k in ('wins','losses','unfinished','eligible')}) for e in exports])))
for p in sorted((root/'screens').glob('*/report.json')):
 s=json.loads(p.read_text());b=next(b for b in next(iter(s['leaderboards'].values())) if b['name']=='selected')
 print(json.dumps(dict(screen=p.parent.name,**{k:b[k] for k in ('wins','losses','unfinished','pending','eligible')})))
