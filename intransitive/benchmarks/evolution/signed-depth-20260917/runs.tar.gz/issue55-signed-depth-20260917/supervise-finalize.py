import os
os.setpriority(os.PRIO_PROCESS,0,19)
import json, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path('/tmp/issue55-signed-depth-20260917/postprocess');ROOT.mkdir(exist_ok=True);START=time.monotonic();DEADLINE=START+max(0,ROOT.parent.joinpath('supervisor.log').stat().st_birthtime+3540-time.time())
ENV=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONPATH=str(Path.cwd()))
measurements=[]
def write(name,value):
 p=ROOT/name;q=p.with_suffix(p.suffix+'.tmp');q.write_text(json.dumps(value,indent=2)+'\n');q.replace(p)
def invoke(name,args):
 start=time.monotonic();peak=0;count=0;anomalies=[];samples=0;observed=set();seen=set();stop=None
 with (ROOT/(name+'.log')).open('w') as log:
  p=subprocess.Popen([sys.executable,*args],stdout=log,stderr=subprocess.STDOUT,env=ENV,start_new_session=True)
  while p.poll() is None:
   now=time.monotonic()
   if now>=DEADLINE and stop is None:p.send_signal(signal.SIGTERM);stop=now
   if stop is not None and now-stop>30:os.killpg(p.pid,signal.SIGKILL)
   snapshot=subprocess.check_output(['ps','-axo','pid=,ppid=,rss=,ni=,stat=,comm='],text=True)
   rows=[]
   for line in snapshot.splitlines():
    bits=line.split(None,5)
    if len(bits)==6:rows.append(dict(pid=int(bits[0]),ppid=int(bits[1]),rss=int(bits[2])*1024,nice=int(bits[3]),state=bits[4],command=bits[5]))
   ids={p.pid}
   while True:
    extra=ids|{r['pid'] for r in rows if r['ppid'] in ids}
    if extra==ids:break
    ids=extra
   tree=[r for r in rows if r['pid'] in ids];samples+=1
   peak=max(peak,sum(r['rss'] for r in tree));count=max(count,len(tree));seen.update(ids)
   for r in tree:
    observed.add(r['nice'])
    if r['nice']!=19:
     event=dict(elapsed=now-start,process=r)
     try:os.setpriority(os.PRIO_PROCESS,r['pid'],19);event['action']='lowered own descendant to nice 19'
     except (ProcessLookupError,PermissionError) as e:event['action']=repr(e)
     anomalies.append(event)
   write('progress.json',dict(phase=name,pid=p.pid,elapsed_seconds=now-START,phase_seconds=now-start,peak_tree_rss_bytes=peak,peak_processes=count,observed_priorities=sorted(observed),priority_anomalies=anomalies,live_processes=tree))
   time.sleep(3)
 result=dict(phase=name,command=[sys.executable,*args],exit_code=p.returncode,wall_seconds=time.monotonic()-start,peak_sampled_tree_rss_bytes=peak,peak_processes=count,samples=samples,sample_interval_seconds=3,observed_priorities=sorted(observed),priority_anomalies=anomalies,observed_pids=sorted(seen),deadline_signalled=stop is not None)
 measurements.append(result);write('measurements.json',dict(phases=measurements,elapsed_seconds=time.monotonic()-START,supervisor_nice=os.getpriority(os.PRIO_PROCESS,0),thread_environment={k:ENV[k] for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}))
 print(json.dumps(result),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if stop is not None:raise SystemExit('Global deadline reached')
invoke('study',[str(ROOT.parent/'finalize.py')])
write('complete.json',dict(elapsed_seconds=time.monotonic()-START,status='complete'))
