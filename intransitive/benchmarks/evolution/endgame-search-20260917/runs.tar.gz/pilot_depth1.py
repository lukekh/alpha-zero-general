import json
from pathlib import Path
import signal
import threading
import time
from intransitive.evolution.engines import EnginePool
from intransitive.tournament.spec import candidate, manifest, protocol
from intransitive.tournament.runner import atomic_json, play_match
from intransitive.tournament.report import report


def main():
 root=Path('/tmp/issue55-strength-20260917/pilot-depth1')
 starts=json.loads((root.parent/'corpus-endgames.json').read_text())
 limits=protocol('depth',depth=1,seconds=2.,node_limit=2_000_000,proof_depth=2,proof_nodes=64,max_plies=96,game_seconds=15.)
 spec=manifest([candidate('unchanged-default'),candidate('balanced-pilot',{'attack_weight':12.,'defence_weight':10.,'pressure_weight':2.})],starts,[limits],position_limit=2)
 atomic_json(root/'manifest.json',spec)
 atomic_json(root/'budget.json',dict(max_seconds=75,max_games=4,max_reserved_work=4*(20_000+96*2_000_000),priority=19))
 cancel=threading.Event()
 for signum in (signal.SIGINT,signal.SIGTERM): signal.signal(signum,lambda *_:cancel.set())
 timer=threading.Timer(75,cancel.set);timer.daemon=True;timer.start()
 pool=EnginePool(2);rows=[];begin=time.monotonic()
 try:
  for task in spec['tasks']:
   if cancel.is_set():break
   row=play_match(spec,task,root/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire)
   rows.append(row)
   print(json.dumps(dict(index=task['index'],status=row['status'],reason=row['reason'],plies=len(row['moves']),active_seconds=row['active_seconds'])),flush=True)
 finally:
  timer.cancel();pool.close()
 result=report(spec,rows);result['wall_seconds']=time.monotonic()-begin
 atomic_json(root/'report.json',result)
 print(json.dumps(dict(wall_seconds=result['wall_seconds'],final_matches=result['final_matches'],boards=[{k:r[k] for k in ('name','wins','losses','unfinished','failures','eligible')} for r in result['leaderboards']['depth']])),flush=True)

if __name__=='__main__':main()
