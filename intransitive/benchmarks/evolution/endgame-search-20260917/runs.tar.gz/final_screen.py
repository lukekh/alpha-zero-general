import time
START=time.monotonic()
import json
from pathlib import Path
import signal
import threading
from intransitive.evolution.engines import EnginePool
from intransitive.tournament.spec import candidate,manifest,protocol
from intransitive.tournament.runner import atomic_json,play_match
from intransitive.tournament.report import report


def main():
 root=Path('/tmp/issue55-strength-20260917');output=root/'final-screen'
 candidates={}
 for folder in sorted((root/'benchmark').glob('*-7[34]')):
  for export in json.loads((folder/'candidates.json').read_text()):
   if not export['search']['eligible']: continue
   identity=export['manifest']['config_hash']
   entry=candidates.setdefault(identity,dict(export=export,observations={}))
   for key in export['validation_match_keys']:
    row=json.loads((folder/'matches'/key/'game.json').read_text())
    who=export['validation']['candidate']
    if who not in row['colours']:continue
    colour=row['colours'].index(who)
    result=dict(win=row['status']=='win' and row['winner']==colour,loss=row['status']=='win' and row['winner']!=colour,status=row['status'])
    entry['observations'].setdefault(key,[]).append(result)
 ranks=[]
 for identity,entry in candidates.items():
  groups=list(entry['observations'].values())
  wins=sum(all(r['win'] for r in g) for g in groups)
  losses=sum(all(r['loss'] for r in g) for g in groups)
  n=len(groups)
  genes=entry['export']['genome']['genes']
  active=sum(genes[g]>0 for g in ('attack','defence','overload','pressure'))
  ranks.append(dict(config_hash=identity,wins=wins,losses=losses,unresolved=n-wins-losses,unique_matches=n,lower=wins/n,completion=(wins+losses)/n,active_modules=active))
 ranks.sort(key=lambda r:(-r['lower'],-r['completion'],r['active_modules'],r['config_hash']))
 best=candidates[ranks[0]['config_hash']]['export']
 corpus=json.loads((root/'corpus-endgames.json').read_text())
 used=set(json.loads((root/'input.json').read_text())['validation'])
 starts=sorted((p for p in corpus if p['pool']=='validation' and p['sha256'] not in used),key=lambda p:p['sha256'])[:3]
 limits=json.loads((root/'input.json').read_text())['limits']
 spec=manifest([candidate('provisional',genome=best['genome']),candidate('unchanged-default')],starts,[limits],pool='validation')
 atomic_json(output/'selection.json',dict(ranking=ranks,selection_rule='eligible training; highest conservative validation win fraction on unique match keys; then completion, fewer active optional modules, stable identity',source_export=best,scope='One final development-validation screen; no held-out positions or default adoption.'))
 atomic_json(output/'manifest.json',spec)
 atomic_json(output/'budget.json',dict(max_seconds=70,max_games=6,max_reserved_work=6*(20_000+192*2_000_000),priority=19))
 atomic_json(root/'provisional-genome.json',best['genome'])
 cancel=threading.Event()
 for signum in (signal.SIGINT,signal.SIGTERM):signal.signal(signum,lambda *_:cancel.set())
 timer=threading.Timer(max(0.,70-(time.monotonic()-START)),cancel.set);timer.daemon=True;timer.start()
 pool=EnginePool(2);rows=[]
 try:
  for task in spec['tasks']:
   if cancel.is_set():break
   row=play_match(spec,task,output/'matches'/(task['id']+'.json'),cancel,engine_factory=pool.acquire)
   rows.append(row)
   print(json.dumps(dict(index=task['index'],status=row['status'],plies=len(row['moves']),active_seconds=row['active_seconds'])),flush=True)
 finally:
  timer.cancel();pool.close()
 result=report(spec,rows);result['wall_seconds_including_imports']=time.monotonic()-START
 atomic_json(output/'report.json',result)
 print(json.dumps(dict(wall_seconds=result['wall_seconds_including_imports'],final_matches=result['final_matches'],boards=[{k:r[k] for k in ('name','wins','losses','unfinished','pending','eligible')} for r in result['leaderboards']['depth']])),flush=True)

if __name__=='__main__':main()
