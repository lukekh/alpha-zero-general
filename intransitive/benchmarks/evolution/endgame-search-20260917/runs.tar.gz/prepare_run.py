import json
from pathlib import Path
import subprocess
from intransitive.evolution.runner import prepare
from intransitive.evolution.strategy import Settings
from intransitive.tournament.spec import protocol
from intransitive.tournament.runner import atomic_json

root=Path('/tmp/issue55-strength-20260917')
settings=Settings(seed=73,population=2,generations=2,mutation_rate=.7,toggle_rate=.3,search_positions=1,validation_positions=1,max_seconds=185.,max_games=40,max_nodes=16_000_000_000,resident_engines=4)
limits=protocol('depth',depth=1,seconds=2.,node_limit=2_000_000,proof_depth=2,proof_nodes=64,max_plies=192,game_seconds=12.)
positions=json.loads((root/'corpus-endgames.json').read_text())
spec=prepare(settings,positions,limits,revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip())
atomic_json(root/'input.json',spec)
atomic_json(root/'design.json',dict(settings=settings.to_dict(),protocol=limits,corpus=dict(seed=155,lines=36,max_plies=240,stage='endgame',selection='first by stable hash within preassigned pool'),optimizer_seeds=[73,74],budget=dict(total_seconds=900,pilot_seconds=127.47282754199114,max_comparison_seconds=740,max_comparison_games=160,max_comparison_reserved_work=64_000_000_000),scope='Exploratory 12-piece endgames only; no general-strength claim or default migration; original eligibility rules retained.'))
print(json.dumps({'manifest':spec['sha256'],'search':spec['search'],'validation':spec['validation']}))
