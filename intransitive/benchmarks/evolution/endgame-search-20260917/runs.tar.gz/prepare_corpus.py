import json
from collections import Counter
from pathlib import Path
from intransitive.tournament.spec import generate_positions, unpack
import numpy as np
root=Path('/tmp/issue55-strength-20260917')
corpus=generate_positions(seed=155,lines=36,max_plies=240)
endgames=[p for p in corpus if p['stage']=='endgame']
(root/'corpus-full.json').write_text(json.dumps(corpus,indent=2)+'\n')
(root/'corpus-endgames.json').write_text(json.dumps(endgames,indent=2)+'\n')
print(json.dumps({'stages':dict(Counter(p['stage'] for p in corpus)),'endgame_pools':dict(Counter(p['pool'] for p in endgames)), 'endgames':[{'id':p['sha256'][:10],'pool':p['pool'],'seed':p['seed'],'plies':len(p['opening_actions']),'pieces':int(np.count_nonzero(unpack(p['state'])[:,:,0]))} for p in sorted(endgames,key=lambda p:p['sha256'])]},indent=2))
