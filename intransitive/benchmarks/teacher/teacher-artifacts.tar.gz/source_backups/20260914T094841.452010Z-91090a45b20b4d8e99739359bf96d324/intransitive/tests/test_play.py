"""Browser-session checks against actual engine transitions and history."""

import unittest
import json
import socket
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier, Thread
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from intransitive.IntransitiveConstants import parse_coordinate
from intransitive.play import GameSession, PlayServer
from intransitive.IntransitiveLogicNumba import Board


class FirstLegalOpponent:
    label = 'Test model'

    def __init__(self):
        self.reloads = 0
        self.fail = False

    def reload(self):
        if self.fail:
            raise RuntimeError('Unavailable checkpoint')
        self.reloads += 1

    def choose(self, state, player):
        if self.fail:
            raise RuntimeError('Inference failed')
        board = Board()
        board.copy_state(state, True)
        return next(i for i, valid in enumerate(board.valid_moves(player)) if valid)


class PlaySessionTests(unittest.TestCase):
    def setUp(self):
        self.game = GameSession()

    def move(self, source, target):
        source, target = list(parse_coordinate(source)), list(parse_coordinate(target))
        move = next(m for m in self.game.snapshot()["legal"]
                    if m["source"] == source and m["target"] == target)
        return self.game.update("move", dict(action=move["action"], revision=self.game.revision))

    def test_capture_and_undo_restore_exact_history(self):
        for source, target in [("C5", "D5"), ("H5", "G4"), ("D5", "E5"), ("G4", "F5")]:
            self.move(source, target)
        before = self.game.board.get_state().tobytes()
        state = self.move("E5", "F5")
        self.assertEqual(state["board"][4][5], 2)
        self.assertEqual(state["noncapture"], 0)
        self.assertEqual(state["moves"][-1], "E5 × F5")
        self.game.update("undo", dict(revision=self.game.revision))
        self.assertEqual(self.game.board.get_state().tobytes(), before)

    def test_repetition_terminal_and_undo(self):
        for _ in range(2):
            for source, target in [("B5", "B6"), ("H5", "H4"), ("B6", "B5"), ("H4", "H5")]:
                state = self.move(source, target)
        self.assertEqual(state["reason"], "repetition")
        self.assertIsNone(state["winner"])
        self.assertEqual(state["legal"], [])
        state = self.game.update("undo", dict(revision=self.game.revision))
        self.assertEqual(state["reason"], "ongoing")
        self.assertTrue(state["legal"])

    def test_invalid_and_stale_moves_are_atomic(self):
        self.move("B5", "B6")
        before = self.game.snapshot()
        for data in [dict(action=-1, revision=1), dict(action=True, revision=1),
                     dict(action=before["legal"][0]["action"], revision=0)]:
            with self.assertRaises(ValueError):
                self.game.update("move", data)
            self.assertEqual(self.game.snapshot(), before)

    def test_restart_clears_history_and_counters(self):
        initial = self.game.board.get_state().tobytes()
        self.move("B5", "B6")
        state = self.game.update("restart", dict(revision=1))
        self.assertEqual(self.game.board.get_state().tobytes(), initial)
        self.assertEqual(state["moves"], [])
        self.assertEqual(state["ply"], 0)
        with self.assertRaises(ValueError):
            self.game.update("undo", dict(revision=2))


class AIPlaySessionTests(unittest.TestCase):
    def setUp(self):
        self.opponent = FirstLegalOpponent()
        self.game = GameSession(self.opponent)

    def update(self, command, **data):
        return self.game.update(command, dict(revision=self.game.revision, **data))

    def human_move(self):
        return self.update('move', action=self.game.snapshot()['legal'][0]['action'])

    def test_reply_and_undo_restore_complete_human_turn(self):
        initial = self.game.board.get_state().tobytes()
        self.assertTrue(self.human_move()['ai_turn'])
        reply = self.update('ai')
        self.assertFalse(reply['ai_turn'])
        self.assertEqual(reply['ply'], 2)
        self.assertEqual(reply['player'], 0)
        self.update('undo')
        self.assertEqual(self.game.board.get_state().tobytes(), initial)

    def test_red_opening_and_undo_keep_ai_opening(self):
        state = self.update('restart', human_player=1)
        self.assertTrue(state['ai_turn'])
        self.assertEqual(self.opponent.reloads, 1)
        opening = self.update('ai')
        self.assertFalse(opening['can_undo'])
        before = self.game.board.get_state().tobytes()
        with self.assertRaises(ValueError):
            self.update('undo')
        self.human_move()
        self.update('ai')
        self.update('undo')
        self.assertEqual(self.game.board.get_state().tobytes(), before)

    def test_turn_ownership_and_stale_ai_requests_are_atomic(self):
        with self.assertRaises(ValueError):
            self.update('ai')
        self.human_move()
        before = self.game.snapshot()
        with self.assertRaises(ValueError):
            self.human_move()
        with self.assertRaises(ValueError):
            self.game.update('ai', {'revision': 0})
        self.assertEqual(self.game.snapshot(), before)
        self.update('ai')
        with self.assertRaises(ValueError):
            self.update('ai')

    def test_inference_and_reload_failure_preserve_game(self):
        self.human_move()
        before = self.game.snapshot()
        self.opponent.fail = True
        for command in ('ai', 'restart'):
            with self.assertRaises(RuntimeError):
                self.update(command)
            self.assertEqual(self.game.snapshot(), before)
        self.opponent.fail = False
        self.update('ai')

    def test_human_can_undo_before_ai_reply(self):
        self.human_move()
        state = self.update('undo')
        self.assertEqual(state['ply'], 0)
        self.assertFalse(state['ai_turn'])

    def test_terminal_human_move_does_not_request_ai(self):
        # Repetition ends the game without scheduling another AI move.
        for _ in range(2):
            for source, target in [('B5', 'B6'), ('H5', 'H4'), ('B6', 'B5'), ('H4', 'H5')]:
                self.game.human_player = self.game.board.get_next_player()
                source, target = list(parse_coordinate(source)), list(parse_coordinate(target))
                action = next(m['action'] for m in self.game.snapshot()['legal']
                              if m['source'] == source and m['target'] == target)
                state = self.update('move', action=action)
        self.assertEqual(state['reason'], 'repetition')
        self.assertFalse(state['ai_turn'])
        with self.assertRaises(ValueError):
            self.update('ai')


class SelectableOpponentTests(unittest.TestCase):
    def test_switch_all_opponents_and_independent_options(self):
        from itertools import product
        from intransitive.play import OpponentFactory
        from intransitive.heuristics import SearchConfig
        factory = OpponentFactory(config=SearchConfig(max_depth=1, time_limit=5, node_limit=500000))
        session = GameSession(opponent_factory=factory)
        for flags in product((False, True), repeat=3):
            options = dict(zip(('attack_enabled', 'defence_enabled', 'overload_enabled'), flags))
            snapshot = session.update('restart', dict(revision=session.revision, opponent='alphabeta',
                                                      human_player=1, ab_options=options))
            self.assertEqual({key: snapshot['ab_options'][key] for key in options}, options)
            self.assertEqual(snapshot['ab_options']['max_depth'], factory.config.max_depth)
            self.assertTrue(snapshot['ai_turn'])
            result = session.update('ai', dict(revision=session.revision))
            self.assertEqual(result['ply'], 1)
            self.assertIsNotNone(result['analysis'])
        for opponent in ('random', 'greedy', 'local'):
            snapshot = session.update('restart', dict(revision=session.revision, opponent=opponent))
            self.assertEqual(snapshot['opponent'], opponent)
            self.assertEqual(snapshot['mode'], 'local' if opponent == 'local' else 'ai')

    def test_invalid_selection_or_options_preserve_game(self):
        from intransitive.play import OpponentFactory
        session = GameSession(opponent_factory=OpponentFactory())
        before = session.snapshot()
        for options in ({'opponent': 'model'}, {'opponent': 'unknown'},
                        {'opponent': 'alphabeta', 'ab_options': {'attack_enabled': 1}},
                        {'opponent': 'alphabeta', 'ab_options': {'unknown': 999}},
                        {'opponent': 'alphabeta', 'ab_options': ['attack']}):
            with self.assertRaises(ValueError):
                session.update('restart', dict(revision=session.revision, **options))
            self.assertEqual(session.snapshot(), before)

    def test_search_limits_round_trip_and_reach_the_player(self):
        from intransitive.play import OpponentFactory
        from intransitive.heuristics import SearchConfig
        factory = OpponentFactory(config=SearchConfig(max_depth=6, time_limit=2.5, node_limit=700000))
        session = GameSession(opponent_factory=factory)
        # A page opened in local mode must still show the configured defaults.
        self.assertEqual(session.snapshot()['ab_options']['max_depth'], 6)
        self.assertEqual(session.snapshot()['ab_options']['time_limit'], 2.5)
        options = dict(max_depth=1, time_limit=5., node_limit=500000, attack_enabled=True)
        state = session.update('restart', dict(revision=0, opponent='alphabeta',
                                               human_player=1, ab_options=options))
        for key, value in options.items():
            self.assertEqual(state['ab_options'][key], value)
            self.assertEqual(getattr(session.opponent.config, key), value)
        reply = session.update('ai', dict(revision=state['revision']))
        self.assertEqual(reply['ply'], 1)
        for key, value in options.items():
            self.assertEqual(reply['analysis']['config'][key], value)
        self.assertLessEqual(session.opponent.last_result.completed_depth, 1)
        # Per-game settings do not mutate the factory's CLI defaults.
        self.assertEqual(factory.config.max_depth, 6)

    def test_invalid_search_limits_leave_existing_game_unchanged(self):
        from intransitive.play import OpponentFactory
        session = GameSession(opponent_factory=OpponentFactory())
        session.update('move', dict(revision=0, action=session.snapshot()['legal'][0]['action']))
        before = session.snapshot()
        for key, values in {
            'max_depth': [-1, 65, 2.5, True, '4', None],
            'time_limit': [-1, float('inf'), float('nan'), True, '5', None],
            'node_limit': [-1, 2.5, True, '1000', None],
        }.items():
            for value in values:
                with self.subTest(key=key, value=value):
                    with self.assertRaises(ValueError):
                        session.update('restart', dict(revision=session.revision,
                            opponent='alphabeta', ab_options={key: value}))
                    self.assertEqual(session.snapshot(), before)
        for options in ([], False, ''):
            with self.assertRaises(ValueError):
                session.update('restart', dict(revision=session.revision,
                    opponent='alphabeta', ab_options=options))
            self.assertEqual(session.snapshot(), before)


class PlayServerTests(unittest.TestCase):
    def setUp(self):
        self.game = GameSession()
        self.initial = self.game.snapshot()  # Warm compilation outside request deadlines.
        self.server = PlayServer(('127.0.0.1', 0), self.game)
        self.thread = Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.url = f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)

    def test_idle_browser_connection_does_not_block_state_or_page(self):
        with socket.create_connection(self.server.server_address, timeout=2):
            with urlopen(self.url + '/api/state', timeout=2) as response:
                state = json.load(response)
            self.assertEqual(state['pgn'], self.initial['pgn'])
            with urlopen(self.url, timeout=2) as response:
                self.assertIn(b'id="copy-position"', response.read())

    def test_concurrent_moves_with_same_revision_apply_only_once(self):
        barrier = Barrier(2)
        body = json.dumps(dict(revision=0, action=self.initial['legal'][0]['action'])).encode()

        def move():
            request = Request(self.url + '/api/move', data=body,
                              headers={'Content-Type': 'application/json'})
            barrier.wait(timeout=3)
            try:
                with urlopen(request, timeout=3) as response:
                    return response.status
            except HTTPError as exc:
                exc.close()
                return exc.code

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(lambda _: move(), range(2)))
        self.assertEqual(sorted(results), [200, 400])
        self.assertEqual(self.game.revision, 1)
        self.assertEqual(len(self.game.moves), 1)


if __name__ == "__main__":
    unittest.main()
