"""Intransitive game implementation."""
