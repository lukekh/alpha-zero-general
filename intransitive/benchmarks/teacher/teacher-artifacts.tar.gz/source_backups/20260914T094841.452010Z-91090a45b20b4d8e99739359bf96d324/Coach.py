import logging
import os
import sys
from collections import deque
import pickle
import zlib
from tqdm import tqdm, trange
from queue import SimpleQueue, Empty
from threading import Thread, Lock, Event

from random import shuffle
import numpy as np

from Arena import Arena
from MCTS import MCTS

log = logging.getLogger(__name__)

class Coach():
	"""
	This class executes the self-play + learning. It uses the functions defined
	in Game and NeuralNet. args are specified in main.py.
	"""

	def __init__(self, game, nnet, args):
		self.game = game
		self.nnet = nnet
		self.pnet = self.nnet.__class__(self.game, self.nnet.args)  # the competitor network
		self.args = args
		self.mcts = MCTS(self.game, self.nnet, self.args, dirichlet_noise=(self.args.dirichletAlpha!=0))
		self.trainExamplesHistory = []  # history of examples from args.numItersForTrainExamplesHistory latest iterations
		self.skipFirstSelfPlay = nnet.requestKnowledgeTransfer  # can be overriden in loadTrainExamples()
		self.consecutive_failures = 0
		self.nb_threads = self.args.parallel_inferences

	def executeEpisode(self, my_mcts=None, my_game=None, rng=None):
		"""
		This function executes one episode of self-play, starting with player 0.
		As the game is played, each turn is added as a training example to
		trainExamples. The game is played till the game ends. After the game
		ends, the outcome of the game is used to assign values to each example
		in trainExamples.

		Returns:
			trainExamples: (canonicalBoard, pi, outcome, valids, q) tuples,
				or compressed pickles of those tuples. Outcome and Q vectors
				use current-player order for every symmetry of that example.
		"""
		if my_mcts is None:
			my_mcts = self.mcts
		if my_game is None:
			my_game = self.game
		trainExamples = []
		board = my_game.getInitBoard()
		curPlayer = 0
		episodeStep = 0

		while True:
			episodeStep += 1
			canonicalBoard = my_game.getCanonicalForm(board, curPlayer)
			pi, q, is_full_search = my_mcts.getActionProb(canonicalBoard, temp=1.)
			action = random_pick(pi, temperature=self.temp_for_selfplay(episodeStep), rng=rng)

			if is_full_search:
				valids = my_game.getValidMoves(canonicalBoard, 0)
				sym = my_game.getSymmetries(canonicalBoard, pi, valids)
				# Symmetry triples retain the current-player frame, including Q.
				for b, p, v in sym:
					trainExamples.append([b, p, curPlayer, v, q])

			board, curPlayer = my_game.getNextState(board, curPlayer, action)

			r = my_game.getGameEnded(board, curPlayer)
			if r.any():
				final_scores = [my_game.getScore(board, p) for p in range(my_game.num_players)]
				trainExamples = [(
					x[0],                                # board
					x[1],                                # policy
					np.roll(r, -x[2]),                   # winner
					x[3],                                # valids
					x[4],                                # Q estimates
				) for x in trainExamples]

				return trainExamples if self.args.no_compression else [zlib.compress(pickle.dumps(x), level=1) for x in trainExamples]

	def executeEpisodes_batch(self, i_thread, shared_memory, locks, finished):
		# Execute an episode in a thread until need to evaluate NN
		# then unlock next threads, etc until batch of inferences to do is full
		# then server runs inferences on batch.
		# Each worker has a fixed quota, including zero when numEps < workers.
		locks[i_thread].acquire()
		batch_info = (i_thread, i_thread+self.nb_threads, shared_memory, locks)
		for episode_id in range(i_thread, self.args.numEps, self.nb_threads):
			my_game = self.game.__class__()
			my_game.getInitBoard()
			my_mcts = MCTS(my_game, self.nnet, self.args, dirichlet_noise=(self.args.dirichletAlpha!=0), batch_info=batch_info)
			episode = self.executeEpisode(my_mcts, my_game, rng=self.episode_rng(episode_id))
			self.examplesQueue.put(episode)

		shared_memory[i_thread] = None # Do not infer stale inputs from a finished worker.
		finished[i_thread].set()
		while shared_memory[-1] != 2: # Pass the token until every worker has finished.
			locks[i_thread+1].release()
			locks[i_thread].acquire()
		locks[i_thread+1].release()

	def episode_rng(self, episode_id):
		"""Optional per-episode seed, independent of worker scheduling."""
		seed = getattr(self.args, 'selfplay_seed', None)
		if seed is None:
			return None
		return np.random.default_rng(np.random.SeedSequence([seed, episode_id]))

	def executeEpisodes(self):
		iterationTrainExamples = deque([], maxlen=self.args.maxlenOfQueue)
		if self.nb_threads == 1:
			for episode_id in trange(self.args.numEps, desc="Self Play", ncols=120):
				rng = self.episode_rng(episode_id)
				iterationTrainExamples += self.executeEpisode(**({"rng": rng} if rng is not None else {}))
				self.mcts = MCTS(self.game, self.nnet, self.args, dirichlet_noise=(self.args.dirichletAlpha!=0))
				if len(iterationTrainExamples) == self.args.maxlenOfQueue:
					log.warning(f'saturation of elements in iterationTrainExamples, think about decreasing numEps or increasing maxlenOfQueue')
					break
		else:
			# N slots for NN inputs, N slots for NN ouputs, 1 slot for signaling
			# signal: 0 = compute assigned episodes, 2 = stop
			shared_memory = [None] * (2*self.nb_threads) + [0]
			# list of Locks: "0;n-1" are MCTSs and "n" is the batch NN processor
			locks = [Lock() for _ in range(self.nb_threads+1)]

			self.examplesQueue = SimpleQueue()
			[l.acquire() for l in locks]
			finished = [Event() for _ in range(self.nb_threads)]
			threads_list = [Thread(target=self.executeEpisodes_batch, args=(i_thread, shared_memory, locks, finished)) for i_thread in range(self.nb_threads)]
			threads_list.append(Thread(target=self.nnet.predict_server, args=(self.nb_threads, shared_memory, locks)))
			[t.start() for t in threads_list]

			progress = tqdm(total=self.args.numEps, desc="Self Play", ncols=120, smoothing=0.1, disable=None)
			while not all(event.is_set() for event in finished):
				try:
					iterationTrainExamples += self.examplesQueue.get(timeout=0.05)
					progress.update()
				except Empty:
					pass
			# Every producer has finished; collect any last episodes before shutdown.
			while not self.examplesQueue.empty():
				iterationTrainExamples += self.examplesQueue.get_nowait()
				progress.update()
			shared_memory[-1] = 2
			[t.join() for t in threads_list]
			progress.close()

		MCTS.reset_all_search_trees()
		return iterationTrainExamples

	def learn(self):
		"""
		Performs numIters iterations with numEps episodes of self-play in each
		iteration. After every iteration, it retrains neural network with
		examples in trainExamples (which has a maximum length of maxlenofQueue).
		It then pits the new neural network against the old one and accepts it
		only if it wins >= updateThreshold fraction of decisive games. Draws
		are excluded from that ratio; an all-draw comparison rejects the candidate.
		"""

		for i in range(1, self.args.numIters + 1):
			# examples of the iteration
			if not self.skipFirstSelfPlay or i > 1:
				iterationTrainExamples = self.executeEpisodes()
				if len(iterationTrainExamples) == self.args.maxlenOfQueue:
					log.warning(f'saturation of elements in iterationTrainExamples, think about decreasing numEps or increasing maxlenOfQueue')

				# save the iteration examples to the history 
				self.trainExamplesHistory.append(iterationTrainExamples)

				# Check average number of valid moves, and compare to Dirichlet
				if self.args.no_compression:
					nb_valid_moves = [sum(x[3]) for x in iterationTrainExamples]
				else:
					nb_valid_moves = [sum(pickle.loads(zlib.decompress(x))[3]) for x in iterationTrainExamples]
				avg_valid_moves = sum(nb_valid_moves) / len(nb_valid_moves)
				if self.args.dirichletAlpha > 0 and not (1/1.5 < self.args.dirichletAlpha / (10/avg_valid_moves) < 1.5):
					print(f'There are about {avg_valid_moves:.1f} valid moves per state, so I advise to set dirichlet to {10/avg_valid_moves:.1f} instead')

			if self.args.profile:
				return

			if len(self.trainExamplesHistory) > self.args.numItersHistory:
				self.trainExamplesHistory.pop(0)
			# backup history to a file
			self.saveTrainExamples()
			# shuffle examples before training
			trainExamples = []
			for e in self.trainExamplesHistory:
				trainExamples.extend(e)
			shuffle(trainExamples)

			# training new network, keeping a copy of the old one
			self.nnet.save_checkpoint(folder=self.args.checkpoint, filename='temp.pt', additional_keys=vars(self.args))
			self.pnet.load_checkpoint(folder=self.args.checkpoint, filename='temp.pt')
			pmcts = MCTS(self.game, self.pnet, self.args)

			self.nnet.train(trainExamples)
			# Preserve trained weights even if arena rejects them or evaluation fails.
			self.nnet.save_checkpoint(folder=self.args.checkpoint, filename=f'candidate_{i}.pt',
				additional_keys=dict(vars(self.args), candidate_iteration=i))
			nmcts = MCTS(self.game, self.nnet, self.args)

			# log.info('PITTING AGAINST PREVIOUS VERSION')
			arena = Arena(lambda x, n: np.argmax(nmcts.getActionProb(x, temp=self.temp_for_game(n), force_full_search=True)[0]),
						  lambda x, n: np.argmax(pmcts.getActionProb(x, temp=self.temp_for_game(n), force_full_search=True)[0]), self.game)
			nwins, pwins, draws = arena.playGames(self.args.arenaCompare)

			if pwins + nwins == 0 or float(nwins) / (pwins + nwins) < self.args.updateThreshold:
				self.consecutive_failures += 1
				log.info(f'Iter #{i} - new vs previous: {nwins}-{pwins}  ({draws} draws) --> REJECTED ({self.consecutive_failures})')
				self.nnet.load_checkpoint(folder=self.args.checkpoint, filename='temp.pt')
				if self.consecutive_failures >= self.args.stop_after_N_fail and i < self.args.numIters:
					log.error('Exceeded threshold number of consecutive fails, stopping process')
					exit()
			else:
				log.info(f'Iter #{i} - new vs previous: {nwins}-{pwins}  ({draws} draws) --> ACCEPTED')
				self.nnet.save_checkpoint(folder=self.args.checkpoint, filename=self.getCheckpointFile(i), additional_keys=vars(self.args))
				self.nnet.save_checkpoint(folder=self.args.checkpoint, filename='best.pt', additional_keys=vars(self.args))
				self.consecutive_failures = 0

	def getCheckpointFile(self, iteration):
		return 'checkpoint_' + str(iteration) + '.pt'

	def saveTrainExamples(self):
		folder = self.args.checkpoint
		if not os.path.exists(folder):
			os.makedirs(folder)
		filename = os.path.join(folder, "checkpoint.examples")
		with open(filename, "wb") as f:
			pickle.dump(self.trainExamplesHistory, f)

	def loadTrainExamples(self):
		modelFile = self.args.load_folder_file
		examplesFile = os.path.dirname(modelFile) + "/checkpoint.examples"
		if not os.path.isfile(examplesFile):
			log.warning(f'File "{examplesFile}" with trainExamples not found!')
			if not self.args.useray:
				r = input("Continue? [y|n]")
				if r != "y":
					sys.exit()
			return
	
		log.info("File with trainExamples found. Loading it...")
		with open(examplesFile, "rb") as f:
			self.trainExamplesHistory = pickle.load(f)
		
		# Harmonize compression use in loaded examples
		if type(self.trainExamplesHistory[0][0]) is tuple and not self.args.no_compression:
			for i in range(len(self.trainExamplesHistory)):
				for j in range(len(self.trainExamplesHistory[i])):                    
					self.trainExamplesHistory[i][j] = zlib.compress(pickle.dumps(self.trainExamplesHistory[i][j]), level=1)
		elif type(self.trainExamplesHistory[0][0]) is not tuple and self.args.no_compression:
			for i in range(len(self.trainExamplesHistory)): 
				for j in range(len(self.trainExamplesHistory[i])):
					self.trainExamplesHistory[i][j] = pickle.loads(zlib.decompress(self.trainExamplesHistory[i][j]))
		log.info('Loading done!')

		# cleaning
		if len(self.trainExamplesHistory) > self.args.numItersHistory:
			self.trainExamplesHistory = self.trainExamplesHistory[-self.args.numItersHistory:]
			log.info('Reduced history in loaded examples')
		for history in self.trainExamplesHistory:
			if len(history) > self.args.maxlenOfQueue:
				for _ in range(len(history), self.args.maxlenOfQueue, -1):
					history.pop()
				log.info('Reduced nb of items in one history of loaded examples')


	# Calculates the exponential decay for temperature during self-plays
	def temp_for_selfplay(self, n):
		t_begin, t_end, half_life = self.args.temperature[0], self.args.temperature[1], self.args.tempThreshold
		if half_life < 0:
			return t_end if n > -half_life else t_begin 
		else:
			return t_end + (t_begin - t_end) * (0.5 ** (n / half_life))

	# Calculates the exponential decay for temperature during test games
	def temp_for_game(self, n):
		t_begin, t_end, half_life = 0.5, 0.0, abs(self.args.tempThreshold)
		return t_end + (t_begin - t_end) * (0.5 ** (n / half_life))

def applyTemperatureAndNormalize(probs, temperature, rng=None):
	if temperature == 0:
		bests = np.array(np.argwhere(probs == np.max(probs))).flatten()
		result = [0] * len(probs)
		result[(np.random if rng is None else rng).choice(bests)] = 1
	else:
		result = [x ** (1. / temperature) for x in probs]
		result_sum = float(sum(result))
		result = [x / result_sum for x in result]
	return result

def random_pick(probs, temperature=1., rng=None):
	probs_with_temp = applyTemperatureAndNormalize(probs, temperature, rng=rng)
	pick = (np.random if rng is None else rng).choice(len(probs_with_temp), p=probs_with_temp)
	return pick

if __name__ == "__main__":
	import argparse

	parser = argparse.ArgumentParser(description='Examples loader')
	parser.add_argument('input', metavar='example filename', nargs='*'                 , help='list of examples to load (.examples files)')
	parser.add_argument('--output'    , '-o', action='store', default='../results/new' , help='Prefix for output files')
	parser.add_argument('--binarize'  , '-b', action='store_true', help='Transform policy into binary one')
	args = parser.parse_args()

	training, testing = [], []
	for filename in args.input:
		print(f'Loading {filename}...')
		with open(filename, "rb") as f:
			new_input = pickle.load(f)
			print(f'size = {[len(x) for x in new_input]}, total = {sum([len(x) for x in new_input])}')
			training += new_input[:-1]
			testing += [list(x)[::8] for x in new_input[-1:]] # Remove symmetries

	# for filename in args.input:
	#     print(f'Loading {filename}...')
	#     with open(filename, "rb") as f:
	#         new_input = pickle.load(f)
	#         print(f'size = {[len(x) for x in new_input]}, total = {sum([len(x) for x in new_input])}')
	#         training += new_input[-3:]
	# testing = [list(training[-1])[::8]]
	# training = training[:-1]
	
	if args.binarize:
		print('Binarizing policy...')
		for t in [training, testing]:
			for i in range(len(t)):
				print(i, end=' ')
				for j in range(len(t[i])):
					data = pickle.loads(zlib.decompress(t[i][j]))
					policy = data[1]
					bestA = np.argmax(policy)
					new_policy = np.zeros_like(policy)
					new_policy[bestA] = 1
					data = (data[0], new_policy, data[2], data[3], data[4], data[5])
					t[i][j] = zlib.compress(pickle.dumps(data), level=1)
			print()

	# breakpoint()

	for t, name in [(training, 'training'), (testing, 'testing')]:
		filename = args.output + '_' + name + '.examples'
		print(f'total size {name} = {sum([len(x) for x in t])} --> writing to {filename}')
		with open(filename, "wb") as f:
			pickle.dump(t, f)
		# print(f'Testing...')
		# with open(filename, "rb") as f:
		#     new_input = pickle.load(f)
		#     print(f'size = {[len(x) for x in new_input]}, total = {sum([len(x) for x in new_input])}')
